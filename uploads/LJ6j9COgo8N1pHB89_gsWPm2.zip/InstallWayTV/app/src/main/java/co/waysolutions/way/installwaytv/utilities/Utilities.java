package co.waysolutions.way.installwaytv.utilities;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import co.waysolutions.way.installwaytv.R;

/**
 * Created by hp on 20/02/2017.
 */
public class Utilities {

    public static boolean isAppRunning(Context context, String packageName,Boolean closeApp) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> procInfos = activityManager.getRunningAppProcesses();
        for (int i = 0; i < procInfos.size(); i++) {
            if (procInfos.get(i).processName.equals(packageName)) {
                if(closeApp) {
                    android.os.Process.killProcess(procInfos.get(i).pid);
                    activityManager.killBackgroundProcesses(packageName);
                }
                return true;
            }
        }
        return false;
    }

    public static boolean isPackageInstalled(String packagename, PackageManager packageManager) {
        try {
            packageManager.getPackageInfo(packagename, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public static void UninstallAPP(String packagename){
        try {
            String command;
            //command = "adb install -r " + filename;
            command = "pm uninstall " + packagename;
            Process proc = Runtime.getRuntime().exec(new String[] { "su", "-c", command });
            proc.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void InstallAPK(String filename){
        File file = new File(filename);
        if(file.exists()){
            try {
                String command;
                //command = "adb install -r " + filename;
                command = "pm install -r " + filename;
                Process proc = Runtime.getRuntime().exec(new String[] { "su", "-c", command });
                proc.waitFor();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean CreateFile(InputStream iS, String NombreArchivo, Activity act){
        boolean retorno = false;

        try {
            byte[] buffer = new byte[1024];
            BufferedInputStream inStream = new BufferedInputStream(iS, 1024 * 10);
            //iS.read(buffer);

            String str_SaveFolderNameBS = GetDirectorySave(act)
                    + "//." + act.getResources().getString(R.string.app_name) + "installs";

            File BSDirectory = new File(str_SaveFolderNameBS);
            if (!BSDirectory.exists())
                BSDirectory.mkdirs();

            File targetFile = new File(BSDirectory.getPath()+"//"+ NombreArchivo);

            int read = 0;
            OutputStream outStream = new FileOutputStream(targetFile);

            while ((read = inStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, read);
            }
            outStream.close();
            inStream.close();
            iS.close();

            retorno = true;
        }
        catch (Exception e) {
            Log.e("UT-CRF-Error", e.getMessage());
            e.printStackTrace();
        }

        return retorno;
    }

    public static String getPath(Uri uri,Activity act) {
        int column_index;

        String[] projection = {MediaStore.MediaColumns.DATA};
        Cursor cursor = act.getContentResolver().query(uri, projection, null, null, null);
        column_index = cursor
                .getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        cursor.moveToFirst();

        return cursor.getString(column_index);
    }

    public static String GetDirectoryPath(Activity act){
        String str_SaveFolderNameBS = GetDirectorySave(act)
                + "//." + act.getResources().getString(R.string.app_name) + "installs";

        File BSDirectory = new File(str_SaveFolderNameBS);
        if (!BSDirectory.exists())
            BSDirectory.mkdirs();

        return str_SaveFolderNameBS;
    }

    private static String GetDirectorySave(Activity act){
        if (android.os.Environment.getExternalStorageState().equals(
                android.os.Environment.MEDIA_MOUNTED)){
            return Environment
                    .getExternalStorageDirectory()
                    .getAbsolutePath();

        }else{
            return act.getCacheDir().getAbsolutePath();
        }
    }

}
