package co.waysolutions.way.installwaytv;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.io.IOException;

import co.waysolutions.way.installwaytv.BusinessLayer.DownloadManager;
import co.waysolutions.way.installwaytv.utilities.Utilities;

public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            Runtime.getRuntime().exec("su");
        } catch (IOException e) {
        }
        PackageManager pm = getPackageManager();
        if(Utilities.isPackageInstalled("com.WayViewer.waysurveyviewer.app", pm)) {
            //validar que la versión de la aplicación sea la última

            SharedPreferences prefs = getSharedPreferences(getString(R.string.sharePreferencesName),
                    Context.MODE_PRIVATE);

            String lastVersion = prefs.getString("version", "0");

            if(lastVersion.equals("1.0.1")) {
                Utilities.isAppRunning(this,"com.WayViewer.waysurveyviewer.app",true);
                //lanzar la aplicación
                lanzarAplicacion();

            }else{
                DownloadApkTask ws = new DownloadApkTask(getResources().getString(R.string.fileName));
                String[] params = new String[1];
                String folderVersion = "1.0.1";
                params[0] = getResources().getString(R.string.URLDownload) +"/"+ folderVersion+"/"+getResources().getString(R.string.fileName);
                ws.execute(params);
            }
        }else{
            //instalar la aplicación
            DownloadApkTask ws = new DownloadApkTask(getResources().getString(R.string.fileName));
            String[] params = new String[1];
            String folderVersion = "1.0.1";
            params[0] = getResources().getString(R.string.URLDownload) +"/"+ folderVersion+"/"+getResources().getString(R.string.fileName);
            ws.execute(params);
        }
    }

    private void lanzarAplicacion(){
        PackageManager pm = getPackageManager();
        Intent launchIntent = pm.getLaunchIntentForPackage("com.WayViewer.waysurveyviewer.app");
        if (launchIntent != null) {
            //startActivity(launchIntent);//null pointer check in case package name was not found
            startActivity(launchIntent);
            finish();
            System.exit(0);
        }
    }

    private class DownloadApkTask extends AsyncTask<String, Void, Boolean> {
        String filename;

        public DownloadApkTask(String FileName){filename=FileName;}

        protected Boolean doInBackground(String... urls) {

            return DownloadManager.DownloadFile(MainActivity.this, urls[0], filename);
        }

        protected void onPostExecute(Boolean rta) {
            if(rta) {
                PackageManager pm = getPackageManager();
                if(Utilities.isPackageInstalled("com.WayViewer.waysurveyviewer.app", pm)) {
                    Utilities.UninstallAPP("com.WayViewer.waysurveyviewer.app");
                }

                Utilities.InstallAPK(Utilities.GetDirectoryPath(MainActivity.this) + "//" + getResources().getString(R.string.fileName));

                SharedPreferences prefs = getSharedPreferences(getString(R.string.sharePreferencesName),
                        Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("version", "1.0.1");
                editor.commit();
                //lanzar la aplicación
                lanzarAplicacion();
            }
        }
    }
}
