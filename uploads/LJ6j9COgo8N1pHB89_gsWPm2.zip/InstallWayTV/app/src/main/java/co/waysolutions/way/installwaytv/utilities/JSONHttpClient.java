package co.waysolutions.way.installwaytv.utilities;
        import android.app.Activity;
        import android.util.Base64;
        import android.util.Log;

        import com.google.gson.Gson;

        import java.io.BufferedReader;
        import java.io.BufferedWriter;
        import java.io.InputStream;
        import java.io.InputStreamReader;
        import java.io.OutputStream;
        import java.io.OutputStreamWriter;
        import java.io.UnsupportedEncodingException;
        import java.lang.reflect.Type;
        import java.net.HttpURLConnection;
        import java.net.MalformedURLException;
        import java.net.URL;
        import java.net.URLEncoder;
        import java.util.List;
        import java.util.Map;

/**
 * Created by hp on 26/10/2016.
 */
public class JSONHttpClient {
    public <T> T CallObject(String urlP,
                            final Class<T> objectClass,
                            Map<String, Object> params,
                            String userCredentials,
                            String ServiceType) {
        try {

            String Retorno = executeCall(urlP,userCredentials,params,ServiceType);
            if(Retorno != null) {
                Gson gson = new Gson();
                return gson.fromJson(Retorno, objectClass);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            Log.e("PostObject", "URL: " + urlP + " - Stype:" + ServiceType + " - Exception : " + e.getMessage(), e);
        }
        return null;
    }

    public <T> List<T> CallObject(String urlP,
                                  final Class<T> objectClass,
                                  Type objType,
                                  Map<String, Object> params,
                                  String userCredentials,
                                  String ServiceType) {
        try {

            String Retorno = executeCall(urlP,userCredentials,params,ServiceType);
            if(Retorno != null) {
                Gson gson = new Gson();
                return gson.fromJson(Retorno, objType);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            Log.e("PostObject", "URL: " + urlP + " - Stype:" + ServiceType + " - Exception : " + e.getMessage(), e);
        }
        return null;
    }

    public String CallString(String urlP, Map<String, Object> params, String userCredentials,String ServiceType) {
        String rta = executeCall(urlP,userCredentials,params,ServiceType);
        return rta;
    }

    private String getQuery(Map<String, Object>  params) throws UnsupportedEncodingException
    {
        StringBuilder result = new StringBuilder();
        boolean first = true;

        for (Map.Entry<String, Object> param : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(param.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
        }

        return result.toString();
    }

    private String executeCall(String upLoadServerUri,
                               String userCredentials,
                               Map<String, Object> params,
                               String ServiceType){
        HttpURLConnection conn = null;
        try {
            StringBuilder postData = new StringBuilder();

            if(params != null) {
                if(!ServiceType.equals("POST")) {
                    for (Map.Entry<String, Object> param : params.entrySet()) {
                        if (postData.length() != 0) postData.append('&');
                        postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
                        postData.append('=');
                        postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
                    }
                    upLoadServerUri = upLoadServerUri + "?" + postData.toString();
                }
            }

            URL url = new URL(upLoadServerUri);
            // Open a HTTP  connection to  the URL
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true); // Allow Inputs

            conn.setUseCaches(false); // Don't use a Cached Copy
            if(userCredentials != null) {
                String basicAuth = Base64.encodeToString(userCredentials.getBytes(), Base64.DEFAULT);
                conn.setRequestProperty("Authorization", basicAuth);
            }

            conn.setRequestMethod(ServiceType);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setConnectTimeout(10000);

            if(ServiceType.equals("POST")) {
                //este permite que el método sea POST
                conn.setDoOutput(true); // Allow Outputs

                if(params != null) {
                    OutputStream os = conn.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(os, "UTF-8"));
                    writer.write(getQuery(params));
                    writer.flush();
                    writer.close();
                    os.close();
                }
            }

            BufferedReader br;
            StringBuilder sb = new StringBuilder();
            String output;
            // Responses from the server (code and message)
            if (200 <= conn.getResponseCode() && conn.getResponseCode() <= 299) {

                br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                return sb.toString();
            } else {
                br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                Log.e("executeCall","No se pudo realizar la conexión, Url: " + upLoadServerUri + " - " + sb.toString());
                return null;
            }
        }

        catch (Exception e) {
            e.printStackTrace();
            Log.e("executeCall", "ErrorClient URL - " + upLoadServerUri + " - Exception : " + e.getMessage(), e);
        }
        return null;
    }


    public boolean SaveAndDownloadFile(Activity act,
                                       String Url,
                                       String NombreArchivo){

        boolean retorno = false;

        try {

            /*ExecutorService executor = Executors.newFixedThreadPool(1);
            Future<Response> response = executor.submit(new Request(new URL(Url)));
            InputStream body = response.get().getBody();*/

            URL u = new URL(Url);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            //c.setAllowUserInteraction(false);
            //c.setInstanceFollowRedirects(true);
            c.setRequestMethod("GET");
            c.setDoInput(true);
            c.setUseCaches(false);
            c.setConnectTimeout(100000);
            c.setRequestProperty("Connection", "keep-alive");
            //c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36");
            c.setRequestProperty("Accept-Encoding", "gzip, deflate, sdch");
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            //c.setDoOutput(true);
            //c.connect();
            // c.setRequestMethod("GET");


            //c.connect();
            if (200 <= c.getResponseCode() && c.getResponseCode() <= 299) {
                InputStream in = c.getInputStream();
                retorno = Utilities.CreateFile(in,NombreArchivo,act);

            }
            else {
                BufferedReader br = new BufferedReader(new InputStreamReader((c.getErrorStream())));
                StringBuilder sb = new StringBuilder();
                String output;
                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                Log.e("executeCall", "No se pudo realizar la conexión, Url: " + sb.toString());

            }
        } catch (MalformedURLException e) {
            new RuntimeException();
        } catch (Exception e) {
            new RuntimeException();
        }

        return retorno;
    }

}

