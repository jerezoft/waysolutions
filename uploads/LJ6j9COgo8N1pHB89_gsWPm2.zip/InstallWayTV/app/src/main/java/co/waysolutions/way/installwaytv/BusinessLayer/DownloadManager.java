package co.waysolutions.way.installwaytv.BusinessLayer;

import android.app.Activity;

import co.waysolutions.way.installwaytv.utilities.JSONHttpClient;
import co.waysolutions.way.installwaytv.utilities.Utilities;

/**
 * Created by hp on 20/02/2017.
 */
public class DownloadManager {
    public static boolean DownloadFile(Activity act,String Url, String FileName){
        JSONHttpClient objClient = new JSONHttpClient();
        return objClient.SaveAndDownloadFile(act,Url,FileName);
    }
}
