package co.waysolutions.way.installwaytv;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import co.waysolutions.way.installwaytv.utilities.Utilities;

/**
 * Created by hp on 20/02/2017.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        ConnectivityManager conMgr =
                (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
        if (activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting()) {
            /*SharedPreferences sharedPref = context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE);
            if (sharedPref.getString("RegisterID", "") != "") {
                Intent start_i = new Intent(context, WayViewerSurvey.class);
                start_i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(start_i);
            }else{*/

            //verificar que exista la aplicacion instalada en el dispositivo
            PackageManager pm = context.getPackageManager();
            if(Utilities.isPackageInstalled("com.WayViewer.waysurveyviewer.app", pm)) {
                //validar que la versión de la aplicación sea la última
                if(true) {
                    Intent launchIntent = pm.getLaunchIntentForPackage("com.WayViewer.waysurveyviewer.app");
                    if (launchIntent != null) {
                        //startActivity(launchIntent);//null pointer check in case package name was not found
                        context.startActivity(launchIntent);
                    }
                }else{
                    //lanzar actualizador de la aplicación
                    Intent start_i = new Intent(context, MainActivity.class);
                    start_i.putExtra("activity", "BootReceiver");
                    start_i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(start_i);
                }
            }else{
                //instalar la aplicación
            }
            //}
        }else if (activeNetwork == null) {
            Intent start_i = new Intent(context, BootConexWait.class);
            start_i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(start_i);
        }
    }
}
