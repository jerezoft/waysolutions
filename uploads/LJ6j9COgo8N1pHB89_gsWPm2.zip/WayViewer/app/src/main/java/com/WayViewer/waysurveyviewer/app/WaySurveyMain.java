package com.WayViewer.waysurveyviewer.app;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.provider.Settings;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.Intent;
import android.widget.Toast;

import 	java.io.File;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.DeviceType;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.ParametrizacionInicial;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.ReturnInfo;
import com.WayViewer.waysurveyviewer.app.Utilities.GeneralUtilities;
import com.WayViewer.waysurveyviewer.app.Utilities.Services;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

import WebServices.CallWebServices;


public class WaySurveyMain extends AppCompatActivity {
    private AlertDialog ad;
    public static String rslt="";
    public static ReturnInfo ObjReturn;
    String android_id = "";
    private ProgressDialog progressBar;
    private AlertDialog alertDialog;
    private Button btnIni;
    private Context con;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        setContentView(R.layout.activity_way_survey_main);
        final ConnectivityManager conMgr = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);

        try {
            con =  createPackageContext(getString(R.string.pakagePreference), 0);//first app package name is "com.sharedpref1"
        }
        catch (PackageManager.NameNotFoundException e) {
            Log.e("Not data shared", e.toString());
        }

        //obtener el id generado del equipo
        android_id = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ANDROID_ID);

        String serialnum = null;
        WifiManager wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo();
        serialnum = info.getMacAddress();

        if(serialnum != null){
            android_id+=serialnum;
        }
        //fin obtener el id generado del equipo
        alertDialog = new AlertDialog.Builder(this).create();

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);

        alertDialogBuilder.setTitle("Mensaje");

        // set dialog message
        alertDialogBuilder
                .setTitle("Mensaje")
                .setCancelable(false)
                .setPositiveButton("Aceptar",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // if this button is clicked, close
                        // current activity
                        dialog.cancel();
                    }
                });
                /*.setNegativeButton("No",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // if this button is clicked, just close
                        // the dialog box and do nothing
                        dialog.cancel();
                    }
                });*/

        // create alert dialog
        ad = alertDialogBuilder.create();


        Button btnConf =
       (Button)findViewById(R.id.BtnConf);

        btnIni =
                (Button)findViewById(R.id.BtnLaunch);

        btnConf.setOnClickListener(
                new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(GeneralUtilities.GetUrlWebservices(WaySurveyMain.this).equals("")) {
                            ad.setMessage("No existe parametrización global disponible");
                            ad.show();
                            return;
                        }
                        if (conMgr.getActiveNetworkInfo() == null ) {
                            ad.setMessage("No existe conexión a red, por favor validar y volver a intentar");
                            ad.show();
                        }else {
                            Intent myIntent = new Intent(WaySurveyMain.this, WayViewerConfig.class);
                            WaySurveyMain.this.startActivity(myIntent);
                        }
                    }
                }
        );

        btnIni.setOnClickListener(
                new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(GeneralUtilities.GetUrlWebservices(WaySurveyMain.this).equals("")) {
                            ad.setMessage("No existe parametrización global disponible");
                            ad.show();
                            return;
                        }
                        if (conMgr.getActiveNetworkInfo() == null) {
                            ad.setMessage("No existe conexión a red, por favor validar y volver a intentar");
                            ad.show();
                        }else {
                            //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);

                            SharedPreferences sharedPref = null;
                            if(con != null) {
                                sharedPref = con.getSharedPreferences(
                                        getString(R.string.app_name), Context.MODE_PRIVATE);
                            }else{
                                sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                            }

                            if (sharedPref.getString("RegisterID", "") != "") {
                                AsyncGetINWSCall objWS = new AsyncGetINWSCall();
                                objWS.execute();
                            } else {
                                AsyncRegistrerWSCall objWS = new AsyncRegistrerWSCall();
                                objWS.execute();
                            }
                        }
                    }
                }
        );

        //Obtener parametrizacion general
        AsyncGetParametrization ws = new AsyncGetParametrization();
        ws.execute();
    }

    private void SetPerformClick(){
        Intent intent = getIntent();
        String activity = intent.getStringExtra("activity");
        //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
        SharedPreferences sharedPref = null;
        if(con != null) {
            sharedPref = con.getSharedPreferences(
                    getString(R.string.app_name), Context.MODE_PRIVATE);
        }else{
            sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
        }
        if ((activity != "" && activity != null) || (sharedPref.getString("RegisterID", "") != ""))
            btnIni.performClick();
    }

    public void clearApplicationData() {
        File cache = getCacheDir();
        File appDir = new File(cache.getParent());
        if (appDir.exists()) {
            String[] children = appDir.list();
            for (String s : children) {
                if (!s.equals("lib")) {
                    deleteDir(new File(appDir, s));
                    //Log.i("TAG", "**************** File /data/data/APP_PACKAGE/" + s + " DELETED *******************");
                }
            }
        }
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }

        return dir.delete();
    }
    private class AsyncRegistrerWSCall extends AsyncTask<String, Void, ReturnInfo> {
        @Override
        protected ReturnInfo doInBackground(String... params) {
            return Services.ObtenerIngresoLapinTv(WaySurveyMain.this,android_id);
        }
        @Override
        protected void onPostExecute(ReturnInfo result) {
            if(result != null) {
                if (result.IntCode() == 0 || result.IntError() != 0) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage(result.StrMenssage());
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            return;
                        }
                    });
                    alertDialog.show();
                } else {
                    if (result.StrMenssage() == "") {
                        ad.setMessage("Aun no se ha registrado el equipo, por favor realice el registro y luego vuelva a intentarlo");
                        ad.show();
                    } else {
                        //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                        SharedPreferences sharedPref = null;
                       if(con != null) {
                           sharedPref = con.getSharedPreferences(
                                   getString(R.string.app_name), Context.MODE_PRIVATE);
                       }else{
                           sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                       }

                        SharedPreferences.Editor editor = sharedPref.edit();
                        editor.putString("RegisterID", result.StrMenssage());
                        editor.putString("TvFunctionality", String.valueOf(result.IdTipoPublicidadP()));
                        editor.putString("Sucursal", String.valueOf(result.IdSucursalP()));
                        editor.commit();

                        //llamar el servicio de ingreso para saber cual actividad se debe lanzar
                        AsyncGetINWSCall objWSIN = new AsyncGetINWSCall();
                        objWSIN.execute();
                    }
                }
            }else{
                if (WaySurveyMain.rslt != "") {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("Se ha presentado un error y la solicitud no puede ser atendida");
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                            return;
                        }
                    });
                    alertDialog.show();
                }
            }
            progressBar.dismiss();
        }
        @Override
        protected void onPreExecute() {
            progressBar = ProgressDialog.show(WaySurveyMain.this, "", "Procesando...");
        }
    }

    private class AsyncGetParametrization extends AsyncTask<String, Void, ParametrizacionInicial> {
        @Override
        protected ParametrizacionInicial doInBackground(String... params) {
            return Services.GetInitialParametrization(WaySurveyMain.this);
        }

        @Override
        protected void onPostExecute(ParametrizacionInicial result) {
            if(result.IntError ==1) GeneralUtilities.SaveParametrization(WaySurveyMain.this,result);
            else Log.e("errorParam", result.Mensaje);
            SetPerformClick();
            progressBar.dismiss();
        }

        @Override
        protected void onPreExecute() {
            progressBar = ProgressDialog.show(WaySurveyMain.this, "", "Consultando Parametrización Inicial...");
        }
    }

    /**
     * Llamado al webservice para obtener la información del dispositivo
     */
    private class AsyncGetINWSCall extends AsyncTask<String, Void, ReturnInfo> {
        @Override
        protected ReturnInfo doInBackground(String... params) {
            CallWebServices cso = new CallWebServices();

            String android_id = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ANDROID_ID);

            String serialnum = null;
            WifiManager wifiManager = (WifiManager) WaySurveyMain.this.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wifiManager.getConnectionInfo();
            serialnum = info.getMacAddress();

            if (serialnum != null) {
                android_id += serialnum;
            }

            //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);

            SharedPreferences sharedPref = null;
            if(con != null) {
                sharedPref = con.getSharedPreferences(
                        getString(R.string.app_name), Context.MODE_PRIVATE);
            }else{
                sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
            }

            return Services.IngresarLapinTv(
                    WaySurveyMain.this,
                    sharedPref.getString("RegisterID", ""),
                    android_id
            );
        }

        @Override
        protected void onPostExecute(ReturnInfo result) {
            if (result != null) {
                if (result.IntCode() == 0 || result.IntError() != 0) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage(result.StrMenssage());
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                            return;
                        }
                    });
                    alertDialog.show();
                } else {
                    //agregar el waytoken en las preferencias
                    if(result.WayToken() != null){
                        if(result.WayToken() != "") {
                            //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);

                            SharedPreferences sharedPref = null;
                            if(con != null) {
                                sharedPref = con.getSharedPreferences(
                                        getString(R.string.app_name), Context.MODE_PRIVATE);
                            }else{
                                sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                            }

                            SharedPreferences.Editor editor = sharedPref.edit();
                            Gson gson = new Gson();
                            editor.putString("objInfoConect", gson.toJson(result));
                            editor.putString("WayToken", result.WayToken());
                            editor.commit();
                        }
                    }
                    //indica que es un tv y se debe iniciar la actividad de publicidad
                    if (result.IntCode() == 2) {
                        Intent myIntent = new Intent(WaySurveyMain.this, ActivityPublicity.class);
                        WaySurveyMain.this.startActivity(myIntent);
                    }else if(result.IntCode() == 1){
                        Intent myIntent = new Intent(WaySurveyMain.this, WayViewerSurvey.class);
                        WaySurveyMain.this.startActivity(myIntent);
                    }else{
                        //guardar el ID antes de borrar los datos
                        //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);

                        SharedPreferences sharedPref = null;
                        if(con != null) {
                            sharedPref = con.getSharedPreferences(
                                    getString(R.string.app_name), Context.MODE_PRIVATE);
                        }else{
                            sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                        }

                        String id = sharedPref.getString("RegisterID", "");

                        //si el código es 3 indica que se debe borrar los datos de la cache
                        clearApplicationData();

                        //asignar de nuevo el ID
                        SharedPreferences.Editor editor = sharedPref.edit();
                        editor.putString("RegisterID", id);
                        editor.commit();

                        //realizar el llamado al webservice para actualizar los datos como borrados
                        AsyncUpdateDeleteDataWSCall ws = new AsyncUpdateDeleteDataWSCall();
                        ws.execute();
                    }
                }
            } else {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("Se ha presentado un error y la solicitud no pudo ser atendida");
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                            return;
                        }
                    });
                    alertDialog.show();
            }
            progressBar.dismiss();
        }

        @Override
        protected void onPreExecute() {
            progressBar = ProgressDialog.show(WaySurveyMain.this, "", "Procesando...");
        }
    }
    /********************************************************************************************/

    /**
     * Llamado al webservice para actualizar el estado del registro despues de haber borrado la cache de la aplicación
     * esto solo aplica cuando es una encuesta
     */
    private class AsyncUpdateDeleteDataWSCall extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            CallWebServices cso = new CallWebServices();

            String android_id = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ANDROID_ID);

            //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
            SharedPreferences sharedPref = null;
            if(con != null) {
                sharedPref = con.getSharedPreferences(
                        getString(R.string.app_name), Context.MODE_PRIVATE);
            }else{
                sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
            }

            cso.ActualizarBorrado(sharedPref.getString("RegisterID", ""),
                   3
            );
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            if (WaySurveyMain.ObjReturn != null) {
                if (WaySurveyMain.ObjReturn.IntCode() == 0 || WaySurveyMain.ObjReturn.IntError() != 0) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage(WaySurveyMain.ObjReturn.StrMenssage());
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                            return;
                        }
                    });
                    alertDialog.show();
                } else {
                        Intent myIntent = new Intent(WaySurveyMain.this, WayViewerSurvey.class);
                        WaySurveyMain.this.startActivity(myIntent);
                }
            } else {
                if (WaySurveyMain.rslt != "") {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage(WaySurveyMain.rslt);
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                            return;
                        }
                    });
                    alertDialog.show();
                }
            }
        }
    }

}
