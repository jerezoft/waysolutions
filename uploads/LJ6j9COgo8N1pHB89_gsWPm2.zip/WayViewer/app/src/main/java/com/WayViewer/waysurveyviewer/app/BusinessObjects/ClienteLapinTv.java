package com.WayViewer.waysurveyviewer.app.BusinessObjects;

import java.util.ArrayList;

/**
 * Created by hp on 22/03/2016.
 */
public class ClienteLapinTv extends MensajeSalida {
    public String LlaveCliente;
    public ArrayList<SucursalLapinTv> SucursalList;
}
