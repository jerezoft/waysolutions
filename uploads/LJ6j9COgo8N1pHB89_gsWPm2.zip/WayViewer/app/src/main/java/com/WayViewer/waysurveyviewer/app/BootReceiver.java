package com.WayViewer.waysurveyviewer.app;

/**
 * Created by Manuel on 18/07/2014.
 */
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.provider.Settings;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.ReturnInfo;

import WebServices.CallWebServices;

public class BootReceiver extends BroadcastReceiver {
    public static String rslt="";
    public static ReturnInfo ObjReturn;
    @Override
    public void onReceive(Context context, Intent intent) {
        ConnectivityManager conMgr =
                (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
        if (activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting()) {
            /*SharedPreferences sharedPref = context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE);
            if (sharedPref.getString("RegisterID", "") != "") {
                Intent start_i = new Intent(context, WayViewerSurvey.class);
                start_i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(start_i);
            }else{*/
                Intent start_i = new Intent(context, WaySurveyMain.class);
                start_i.putExtra("activity","BootReceiver");
                start_i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(start_i);
            //}
        }else if (activeNetwork == null) {
            Intent start_i = new Intent(context, BootConexWait.class);
            start_i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(start_i);
        }
    }
}
