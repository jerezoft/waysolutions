package com.WayViewer.waysurveyviewer.app.BusinessObjects;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by hp on 23/10/2014.
 */
public class RankingPublicity implements Parcelable {
    public Double IdRankingIdioma;
    public String Descripcion;
    public String Usuario;
    public String RutaImagen;
    public int TipoArchivo;
    public Boolean YaSeMostroEnParrilla;
    public Boolean Gestionado;

    public RankingPublicity(double _IdRankingIdioma,
                            String _Descripcion,
                            String _Usuario,
                            String _RutaImagen,
                            short _TipoArchivo,
                            Boolean _YaSeMostroEnParrilla){
        this.IdRankingIdioma = _IdRankingIdioma;
        this.Descripcion = _Descripcion;
        this.Usuario = _Usuario;
        this.RutaImagen = _RutaImagen;
        this.TipoArchivo = _TipoArchivo;
        this.YaSeMostroEnParrilla = _YaSeMostroEnParrilla;
    }

    public RankingPublicity( Parcel parcel ){
        IdRankingIdioma = parcel.readDouble();
        Descripcion = parcel.readString();
        Usuario = parcel.readString();
        RutaImagen = parcel.readString();
        TipoArchivo = parcel.readInt();
        YaSeMostroEnParrilla = parcel.readByte() != 0;
        Gestionado = parcel.readByte() != 0;
    }

    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel( Parcel parcel, int flags ){
        parcel.writeDouble(IdRankingIdioma);
        parcel.writeString(Descripcion);
        parcel.writeString(Usuario);
        parcel.writeString(RutaImagen);
        parcel.writeInt(TipoArchivo);
        parcel.writeByte((byte) (YaSeMostroEnParrilla ? 1 : 0));
        parcel.writeByte((byte) (Gestionado ? 1 : 0));
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        @Override
        public RankingPublicity createFromParcel( Parcel parcel ){
            return new RankingPublicity( parcel );
        }

        @Override
        public RankingPublicity[] newArray( int i ){
            return new RankingPublicity[ i ];
        }
    };

}
