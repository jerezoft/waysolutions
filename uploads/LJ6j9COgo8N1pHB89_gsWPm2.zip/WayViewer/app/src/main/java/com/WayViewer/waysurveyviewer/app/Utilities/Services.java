package com.WayViewer.waysurveyviewer.app.Utilities;

import android.app.Activity;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.ClienteLapinTv;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.MensajeSalida;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.ParametrizacionInicial;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.ReturnInfo;
import com.WayViewer.waysurveyviewer.app.R;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by hp on 22/03/2016.
 */
public class Services {
    private static JSONHttpClient ObjGenericCall = new JSONHttpClient();
    public static ParametrizacionInicial GetInitialParametrization(Activity act){
        ParametrizacionInicial retorno =  ObjGenericCall.CallObject(act.getResources().getString(R.string.UrlBase) + "ObtenerParametrizacionInicial",
                ParametrizacionInicial.class, null,
                act.getResources().getString(R.string.usuarioApp) + ":" + act.getResources().getString(R.string.passwordApp),
                "GET");
        if(retorno == null){
            retorno = new ParametrizacionInicial();
            retorno.IntError = 99;
            retorno.Mensaje =  act.getResources().getString(R.string.Generic_error);
        }
        return retorno;
    }

    public static ClienteLapinTv ClientKeySearch(Activity act, String StrCodigo){
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("sLlaveCliente", StrCodigo);
        ClienteLapinTv retorno =  ObjGenericCall.CallObject(GeneralUtilities.GetUrlWebservices(act) + "ObtenerSucursalesXLlaveCliente",
                ClienteLapinTv.class, params,
                act.getResources().getString(R.string.usuarioApp) + ":" + act.getResources().getString(R.string.passwordApp),
                "GET");
        if(retorno == null){
            retorno = new ClienteLapinTv();
            retorno.IntError = 99;
            retorno.Mensaje =  act.getResources().getString(R.string.Generic_error);
        }
        return retorno;
    }

    public static MensajeSalida DeviceRegister(
            Activity act,
            String lIdRegistro,
            String sIdDispositivo,
            String sDescripcion,
            String lIdSucursal,
            String shIdTipoDispositivo,
            String shIdTipoPublicidad,
            String sUsuario,
            String sPassword
    ){
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("lIdRegistro", lIdRegistro);
        params.put("sIdDispositivo", sIdDispositivo);
        params.put("sDescripcion", sDescripcion);
        params.put("lIdSucursal", lIdSucursal);
        params.put("shIdTipoDispositivo", shIdTipoDispositivo);
        params.put("shIdTipoPublicidad", shIdTipoPublicidad);
        params.put("sUsuario", sUsuario);
        params.put("sPassword", sPassword);
        MensajeSalida retorno =  ObjGenericCall.CallObject(GeneralUtilities.GetUrlWebservices(act) + "RegistrarDispositivo",
                MensajeSalida.class, params,
                act.getResources().getString(R.string.usuarioApp) + ":" + act.getResources().getString(R.string.passwordApp),
                "GET");
        if(retorno == null){
            retorno = new MensajeSalida();
            retorno.IntError = 99;
            retorno.Mensaje =  act.getResources().getString(R.string.Generic_error);
        }
        return retorno;
    }

    public static ReturnInfo IngresarLapinTv(
            Activity act,
            String lIdRegistro,
            String sIdDispositivo
    ){
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("lIdRegistro", lIdRegistro);
        params.put("sIdDispositivo", sIdDispositivo);

        ReturnInfo retorno =  ObjGenericCall.CallObject(GeneralUtilities.GetUrlWebservices(act) + "IngresarLapinTv",
                ReturnInfo.class, params,
                act.getResources().getString(R.string.usuarioApp) + ":" + act.getResources().getString(R.string.passwordApp),
                "GET");
        if(retorno == null){
            retorno = new ReturnInfo();
            retorno.IntCode(99);
            retorno.StrMenssage(act.getResources().getString(R.string.Generic_error));
        }
        return retorno;
    }

    public static ReturnInfo ObtenerIngresoLapinTv(
            Activity act,
            String sIdDispositivo
    ){
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("sIdDispositivo", sIdDispositivo);

        ReturnInfo retorno =  ObjGenericCall.CallObject(GeneralUtilities.GetUrlWebservices(act) + "ObtenerIngresoLapinTv",
                ReturnInfo.class, params,
                act.getResources().getString(R.string.usuarioApp) + ":" + act.getResources().getString(R.string.passwordApp),
                "GET");
        if(retorno == null){
            retorno = new ReturnInfo();
            retorno.IntCode(99);
            retorno.StrMenssage(act.getResources().getString(R.string.Generic_error));
        }
        return retorno;
    }
}
