package com.WayViewer.waysurveyviewer.app.Utilities;

import android.app.Activity;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.AnswerAction;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.FileStorage;
import com.WayViewer.waysurveyviewer.app.Utilities.FilesUtil;
import com.google.gson.Gson;

/**
 * Created by hp on 15/03/2016.
 */
public class JSONHttpClient {

    public <T> T CallObject(String urlP,
                            final Class<T> objectClass,
                            Map<String, Object> params,
                            String userCredentials,
                            String ServiceType) {
        try {

            String Retorno = executeCall(urlP,userCredentials,params,ServiceType);
            if(Retorno != null) {
                Gson gson = new Gson();
                return gson.fromJson(Retorno, objectClass);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            Log.e("PostObject", "URL: " + urlP +" - Stype:" + ServiceType + " - Exception : " + e.getMessage(), e);
        }
        return null;
    }

    public AnswerAction CallString(String urlP, Map<String, Object> params, String userCredentials,String ServiceType) {
        AnswerAction objrt = new AnswerAction();

        String rta = executeCall(urlP,userCredentials,params,ServiceType);
        if(rta == null){
            objrt.error = 99;
            objrt.Mensaje = "Se ha presentado un error y no se puede atender la solicitud";
        }else{
            objrt.error = 0;
            objrt.Mensaje =rta;
        }

        return objrt;
    }

    private String executeCall(String upLoadServerUri,
                               String userCredentials,
                               Map<String, Object> params,
                               String ServiceType){
        HttpURLConnection conn = null;
        try {
            StringBuilder postData = new StringBuilder();

            if(params != null) {
                for (Map.Entry<String, Object> param : params.entrySet()) {
                    if (postData.length() != 0) postData.append('&');
                    postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
                    postData.append('=');
                    postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
                }
                upLoadServerUri = upLoadServerUri + "?" + postData.toString();
            }

            URL url = new URL(upLoadServerUri);
            // Open a HTTP  connection to  the URL
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true); // Allow Inputs
            if(ServiceType.equals("POST")) {
                //este permite que el método sea POST
                conn.setDoOutput(true); // Allow Outputs
            }
            conn.setUseCaches(false); // Don't use a Cached Copy
            if(userCredentials != null) {
                String basicAuth = Base64.encodeToString(userCredentials.getBytes(), Base64.DEFAULT);
                conn.setRequestProperty("Authorization", basicAuth);
            }

            conn.setRequestMethod(ServiceType);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setConnectTimeout(10000);

            BufferedReader br;
            StringBuilder sb = new StringBuilder();
            String output;
            // Responses from the server (code and message)
            if (200 <= conn.getResponseCode() && conn.getResponseCode() <= 299) {

                br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                return sb.toString();
            } else {
                br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                Log.e("executeCall","No se pudo realizar la conexión, Url: " + upLoadServerUri + " - " + sb.toString());
                return null;
            }
        }

        catch (Exception e) {
            e.printStackTrace();
            Log.e("executeCall", "ErrorClient URL - " + upLoadServerUri + " - Exception : " + e.getMessage(), e);
        }
        return null;
    }

    public String SaveAndDownloadFile(Activity act,
                                      String Url,
                                      String NombreArchivo,
                                      double fileId,
                                      String RutaArchivoOriginal,
                                      String DescripcionOriginal){
        String strFile = "";
        try {

            /*ExecutorService executor = Executors.newFixedThreadPool(1);
            Future<Response> response = executor.submit(new Request(new URL(Url)));
            InputStream body = response.get().getBody();*/

            //URL u = new URL("http://r1---sn-xuc-cvbe.googlevideo.com/videoplayback?mv=m&mt=1458000844&ms=au&fexp=9405185%2C9405824%2C9416126%2C9420096%2C9420452%2C9422596%2C9423661%2C9423662%2C9424822%2C9425790%2C9425946%2C9426126%2C9426405%2C9427902%2C9429260%2C9429567%2C9429739%2C9431407&sver=3&expire=1458022588&pl=22&mime=video%2Fmp4&upn=Q1LyyTi2cgQ&mn=sn-xuc-cvbe&mm=31&sparams=dur%2Cid%2Cinitcwndbps%2Cip%2Cipbits%2Citag%2Clmt%2Cmime%2Cmm%2Cmn%2Cms%2Cmv%2Cpl%2Cratebypass%2Csource%2Cupn%2Cexpire&ipbits=0&itag=22&source=youtube&id=o-ALCFmJ-uKKzKA3_8DltAehLFQNLbzqiLYeeg0DngCfLE&initcwndbps=683750&key=yt6&ip=186.155.155.167&ratebypass=yes&lmt=1435393393573315&signature=0CF3DDAB36BB1B6BFE831DE66B253BD748F862CB.9348F00C8D1AC33399E898CA64DCFC0A68825D35&dur=19.342&signature=&type=video/mp4;%20codecs=%22avc1.64001F,%20mp4a.40.2%22&title=FlightLinez%20-%20Short%20Publicity%20Video%20(Las%20Vegas,%20Nevada)");
            URL u = new URL(Url);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            //c.setAllowUserInteraction(false);
            //c.setInstanceFollowRedirects(true);
            c.setRequestMethod("GET");
            c.setDoInput(true);
            c.setUseCaches(false);
            c.setConnectTimeout(100000);
            c.setRequestProperty("Connection", "keep-alive");
            //c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36");
            c.setRequestProperty("Accept-Encoding", "gzip, deflate, sdch");
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            //c.setDoOutput(true);
            //c.connect();
            // c.setRequestMethod("GET");


            //c.connect();
            if (200 <= c.getResponseCode() && c.getResponseCode() <= 299) {

                InputStream in = c.getInputStream();
                FileStorage objStorage = new FileStorage();
                objStorage.Id = fileId;
                objStorage.NombreArchivo = NombreArchivo;
                objStorage.TipoArchivo = FilesUtil.TYPE_FILE_VIDEO;
                objStorage.RutaArchivoOrigen = RutaArchivoOriginal;
                objStorage.DescripcionOrigen = DescripcionOriginal;
                objStorage = FilesUtil.ListItemAdd(act,objStorage,in);
                if(objStorage.Error != 99){
                    Log.d("Down", " " + objStorage.RutaArchivo);
                    strFile = objStorage.RutaArchivo;
                }
            }
            else {
                BufferedReader br = new BufferedReader(new InputStreamReader((c.getErrorStream())));
                StringBuilder sb = new StringBuilder();
                String output;
                while ((output = br.readLine()) != null) {
                    sb.append(output);
                }
                Log.e("executeCall", "No se pudo realizar la conexión, Url: " + sb.toString());

            }
        } catch (MalformedURLException e) {
            new RuntimeException();
        } catch (Exception e) {
            new RuntimeException();
        }

        return strFile;
    }
}
