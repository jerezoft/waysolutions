package com.WayViewer.waysurveyviewer.app;

import com.WayViewer.waysurveyviewer.app.Utilities.Counter;
import com.WayViewer.waysurveyviewer.app.Utilities.DownloadFiles;
import com.WayViewer.waysurveyviewer.app.Utilities.FilesUtil;
import com.WayViewer.waysurveyviewer.app.Utilities.GeneralUtilities;
import com.WayViewer.waysurveyviewer.app.util.SystemUiHider;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.WayViewer.waysurveyviewer.app.R;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.android.youtube.player.YouTubePlayer.ErrorReason;
import com.google.android.youtube.player.YouTubePlayer.PlaybackEventListener;
import com.google.android.youtube.player.YouTubePlayer.PlayerStateChangeListener;
import com.google.android.youtube.player.*;

import com.WayViewer.waysurveyviewer.app.Youtube.*;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.*;
import com.google.gson.Gson;


import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.ArrayList;
import java.util.TimerTask;

import WebServices.CallWebServices;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import java.io.File;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.media.AudioManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.WayViewer.waysurveyviewer.app.util.ScalingUtilities;
import com.WayViewer.waysurveyviewer.app.util.ScalingUtilities.ScalingLogic;


/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 *
 * @see SystemUiHider
 */
public class ActivityPublicity extends YouTubeFailureRecoveryActivity implements SurfaceHolder.Callback {
    /**
     * Whether or not the system UI should be auto-hidden after
     * {@link #AUTO_HIDE_DELAY_MILLIS} milliseconds.
     */
    private static final boolean AUTO_HIDE = true;

    /**
     * If {@link #AUTO_HIDE} is set, the number of milliseconds to wait after
     * user interaction before hiding the system UI.
     */
    private static final int AUTO_HIDE_DELAY_MILLIS = 3000;

    /**
     * If set, will toggle the system UI visibility upon interaction. Otherwise,
     * will show the system UI visibility upon interaction.
     */
    private static final boolean TOGGLE_ON_CLICK = true;

    /**
     * The flags to pass to {@link SystemUiHider#getInstance}.
     */
    private static final int HIDER_FLAGS = SystemUiHider.FLAG_HIDE_NAVIGATION;

    /**
     * The instance of the {@link SystemUiHider} for this activity.
     */
    private SystemUiHider mSystemUiHider;

    private static TextView txtMsgRed;
    private static boolean Conex = true;
    private boolean ServerConex = true;
    private boolean validateServer = false;
    private boolean RtaConexServer = true;

    private static YouTubePlayerView playerView;
    private static YouTubePlayer player;
    private static final int REQ_START_STANDALONE_PLAYER = 1;
    private static final int REQ_RESOLVE_SERVICE_MISSING = 2;
    private MyPlayerStateChangeListener playerStateChangeListener;
    private MyPlaybackEventListener playbackEventListener;
    private static int Index = 0;
    private static WebView webView;
    private ProgressDialog progressBar;
    private AlertDialog alertDialog;
    private static ImageView image;
    private static ImageView image2;
    /*private static ImageView imageShare;*/
    private static ImageView imageLogo;
    private static FrameLayout FrameImg;
    private static FrameLayout FrameImg2;
    private static FrameLayout frameVideo;
    private static RelativeLayout infoWay;
    private static RelativeLayout frameVideoWay;
    /*private static RelativeLayout shareExpFrame;
    private static LinearLayout shareexpframeI;*/
    private static TextView txtUserShare;
    private static TextView txtSiteShare;
    private static TextView txtMenssageShare;
    private static TextView txtWayToken;
    private static TextView txtMsgInvitation;
    private static Animation slide;
    private static Animation slideOut;
    private static Animation InvitationIn;
    private static Animation InvitationOut;
    private static int ImgShow = 1;
    private static long timeBtImages = 10000;
    private static int timeAnimation = 5000;
    private static long timeBtImagesActInfo = 2000;
    private static long timeWaitBeginYoutube = 5000;
    private static int timeInvitation = 7000;
    private static boolean ActInfo;
    private static boolean RemoveInfo;
    private static boolean currentRemove = false;


    private static ArrayList<RankingPublicity> ENTRIES;
    private static final String TAG = "WayActivityPublicity";
    public static String rslt = "";
    public static ReturnInfo ObjReturn;
    private static int SenderAct = 2;
    ConnectivityManager conMgr;
    private Timer timer = new Timer();
    private static boolean isFirtsTime = true;

    //variable para el manejo de las imágenes en cache
    private DiskLruCache mDiskLruCache;
    private final Object mDiskCacheLock = new Object();
    private boolean mDiskCacheStarting = true;
    private static final int DISK_CACHE_SIZE = 1024 * 1024 * 10; // 10MB
    private static final int IO_BUFFER_SIZE = 4 * 1024;
    private static final String DISK_CACHE_SUBDIR = "thumbnails";
    private static final int APP_VERSION = 1;
    private static final int VALUE_COUNT = 1;
    //private static DiskLruImageCache objImage;
    /*************************************************************/

    //para el manejo de los videos desde el servidor de WAY
    private static MediaPlayer mediaPlayer;
    private static SurfaceHolder vidHolder;
    private static SurfaceView vidSurface;
    /*************************************************************/

    private static int DESIREDWIDTH = 1600;
    private static int DESIREDHEIGHT = 1200;
    private static int CANTITEMSMAXSHARE = 5;

    private static boolean loadUrlAgain = false;
    private static int ContConexFail = 0;
    //indica que el proceso esta en cambio de imagenes
    private static boolean isInChangeProcess = false;
    //indica que se estan removiendo items
    private static boolean RemovingPendingItems = false;
    //items a remover
    private static ArrayList<RankingPublicity> ENTRIES_remove;

    //indica que se esta descargando un video
    private static boolean DonwloadingVideo = false;

    private static boolean OneImageShowed = false;

    private static Counter countObj;

    private static int FunctionalityTV = -1;

    private Context con;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_activity_publicity);

        try {
            con =  createPackageContext(getString(R.string.pakagePreference), 0);//first app package name is "com.sharedpref1"
        }
        catch (PackageManager.NameNotFoundException e) {
            Log.e("Not data shared", e.toString());
        }

        conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        //variable que indica si se esta realizando una actualización del arreglo de imágenes desde el servidor
        ActInfo = false;

        image = (ImageView) findViewById(R.id.imageView);
        image.setImageBitmap(null);
        image2= (ImageView) findViewById(R.id.imageView2);
        image2.setImageBitmap(null);
        imageLogo= (ImageView) findViewById(R.id.imgLogoCliente);
        FrameImg =(FrameLayout)findViewById(R.id.frameImg1);
        frameVideo = (FrameLayout)findViewById(R.id.frameVideo);
        FrameImg2=(FrameLayout)findViewById(R.id.frameImg2);
        infoWay=(RelativeLayout)findViewById(R.id.WayInfo);
        frameVideoWay = (RelativeLayout)findViewById(R.id.frameVideoWayServ);

        //objetos de compartir experiencias
        /*shareExpFrame=(RelativeLayout)findViewById(R.id.shareexpframe);
        shareexpframeI=(LinearLayout)findViewById(R.id.shareexpframeI);
        imageShare= (ImageView) findViewById(R.id.imageShare);*/
        txtSiteShare= (TextView) findViewById(R.id.txtSiteShare);
        txtUserShare= (TextView) findViewById(R.id.txtUserShare);
        txtMenssageShare= (TextView) findViewById(R.id.txtMsjShare);
        txtWayToken= (TextView) findViewById(R.id.wayToken);
        /*shareExpFrame.setVisibility(View.GONE);
        shareexpframeI.setVisibility(View.GONE);*/

        //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);

        SharedPreferences sharedPref = null;
        if(con != null) {
            sharedPref = con.getSharedPreferences(
                    getString(R.string.app_name), Context.MODE_PRIVATE);
        }else{
            sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
        }

        String TvFunc = sharedPref.getString("TvFunctionality", "");
        if(!TvFunc.equals(""))
            FunctionalityTV = Integer.parseInt(TvFunc);

        //"WayToken \n \t \t"   +
        txtWayToken.setText( sharedPref.getString("WayToken", ""));

        //ocultar el sitio en donde se compartio la experiencia por defecto
        txtSiteShare.setVisibility(View.GONE);


        slide = AnimationUtils.loadAnimation(this, R.anim.slide_in);
        slideOut = AnimationUtils.loadAnimation(this, R.anim.slide_out);

        InvitationIn = AnimationUtils.loadAnimation(this, R.anim.invitationin);
        InvitationOut = AnimationUtils.loadAnimation(this, R.anim.invitationout);

        txtMsgRed = (TextView) findViewById(R.id.TxtConex);
        txtMsgRed.setVisibility(View.GONE);
        imageLogo.setVisibility(View.GONE);

        //mensaje de invitación a waysites
        txtMsgInvitation = (TextView) findViewById(R.id.txtInvitation);
        txtMsgInvitation.setVisibility(View.GONE);
        //-------------------------------------------------------------


        //objetos para el manejo de videos alojados en el servidor de WAY
        vidSurface = (SurfaceView) findViewById(R.id.surfView);
        vidSurface.setZOrderMediaOverlay(true);
        vidHolder = vidSurface.getHolder();
        vidHolder.addCallback(this);
        /*******************************************************************/

        webView = (WebView) findViewById(R.id.webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAppCacheEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setPluginState(WebSettings.PluginState.ON);
        settings.setDatabasePath("/data/data/" + getPackageName() + "/databases");
        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 16) {
            settings.setMediaPlaybackRequiresUserGesture(false);
        }
        settings.setPluginState(WebSettings.PluginState.ON);

        webView.addJavascriptInterface(new WebAppInterface(this), "Android");

        webView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.i(TAG, "Processing webview url click...");
                view.loadUrl(url);
                return true;
            }

            public void onPageFinished(WebView view, String url) {
                Log.i(TAG, "Finished loading URL: " + url);
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e(TAG, "Error: " + description);
                Toast.makeText(ActivityPublicity.this, "Oh no! " + description, Toast.LENGTH_SHORT).show();
                //indica que se perdio la conexión con el servidor
                if (errorCode == -6) {
                    //solo lo hace cuando es un TV o es wayChannel
                    if (ActivityPublicity.ObjReturn != null) {
                        if (ActivityPublicity.ObjReturn.IntCode() == 2) {
                            ServerConex = false;
                            if (RtaConexServer)
                                RtaConexServer = false;
                        }
                    }
                }
            }
        });



        playerView = (YouTubePlayerView) findViewById(R.id.player);
        playerView.initialize(DeveloperKey.DEVELOPER_KEY, this);

        playerStateChangeListener = new MyPlayerStateChangeListener();
        playbackEventListener = new MyPlaybackEventListener();

        ActivityPublicity.FrameImg.setVisibility(View.GONE);
        ActivityPublicity.FrameImg2.setVisibility(View.GONE);
        ActivityPublicity.infoWay.setVisibility(View.GONE);
        /*ActivityPublicity.shareExpFrame.setVisibility(View.GONE);
        ActivityPublicity.shareexpframeI.setVisibility(View.GONE);*/
        ActivityPublicity.playerView.setVisibility(View.VISIBLE);
        ActivityPublicity.frameVideo.setVisibility(View.VISIBLE);
        ActivityPublicity.frameVideoWay.setVisibility(View.GONE);

        //obtener el objeto para carga de información
        GetWorkInfo();


        //validar que exista una lista de storage de imagenes
        if(!FilesUtil.ListExists(ActivityPublicity.this)){
            FilesUtil.ClearFiles(ActivityPublicity.this);
        }else{
            //eliminar los archivos de la carpeta que no estan en la lista
            FilesUtil.DeleteNoFilesInList(ActivityPublicity.this);
        }
        //------------------------------------------------------

        //inicializar objeto para el conteo de hits de publicidad
        countObj = new Counter(GeneralUtilities.GetUrlNotification(ActivityPublicity.this),this);
        //--------------------------------------------------------

        /*InitDiskCacheTask objk = new InitDiskCacheTask();
        objk.execute();*/
        if(savedInstanceState != null) {
            Map<String, String> extraHeaders = new HashMap<String, String>();
            extraHeaders.put("Referer", "http://www.WayReferer.tld/main.html");

            webView.loadUrl(ActivityPublicity.ObjReturn.StrMenssage() + "&PUTY=" + FunctionalityTV, extraHeaders);
            //indica que es un tv
            if (ActivityPublicity.ObjReturn.IntCode() == 2) {
                delayedHide(100);
            }
        }


    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        ActivityPublicity.image2.setImageBitmap(null);
        ActivityPublicity.image.setImageBitmap(null);
        if(ENTRIES != null) {
            savedInstanceState.putParcelableArrayList("ENTRIES", ENTRIES);
        }
        if(ENTRIES_remove != null) {
            savedInstanceState.putParcelableArrayList("ENTRIES_remove", ENTRIES_remove);
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        if(savedInstanceState != null){

                if (savedInstanceState.containsKey("ENTRIES")) {
                    ENTRIES = savedInstanceState.getParcelableArrayList("ENTRIES");
                }

                if (savedInstanceState.containsKey("ENTRIES_remove")) {
                    ENTRIES_remove = savedInstanceState.getParcelableArrayList("ENTRIES_remove");
                }
                 GetWorkInfo();

            Map<String, String> extraHeaders = new HashMap<String, String>();
            extraHeaders.put("Referer", "http://www.WayReferer.tld/main.html");

            webView.loadUrl(ActivityPublicity.ObjReturn.StrMenssage() + "&PUTY=" + FunctionalityTV, extraHeaders);
            //indica que es un tv
            if (ActivityPublicity.ObjReturn.IntCode() == 2) {
                delayedHide(100);
            }
        }
    }


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        // Trigger the initial hide() shortly after the activity has been
        // created, to briefly hint to the user that UI controls
        // are available.
        if (WayViewerSurvey.ObjReturn != null) {
            if (WayViewerSurvey.ObjReturn.IntCode() == 2) {
                delayedHide(100);
            }
        }
    }

    private void setFullScreen() {
        final View contentView = findViewById(R.id.webView);

        // Set up an instance of SystemUiHider to control the system UI for
        // this activity.
        mSystemUiHider = SystemUiHider.getInstance(this, contentView, HIDER_FLAGS);
        mSystemUiHider.setup();
        mSystemUiHider
                .setOnVisibilityChangeListener(new SystemUiHider.OnVisibilityChangeListener() {
                    @Override
                    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
                    public void onVisibilityChange(boolean visible) {
                        if (visible && AUTO_HIDE) {
                            // Schedule a hide().
                            delayedHide(AUTO_HIDE_DELAY_MILLIS);
                        }
                    }
                });

        // Set up the user interaction to manually show or hide the system UI.
        contentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TOGGLE_ON_CLICK) {
                    mSystemUiHider.toggle();
                } else {
                    mSystemUiHider.show();
                }
            }
        });

        delayedHide(100);

        //validar conexion a red
        timer = new Timer();
        timer.schedule(new ConexTask(), 0, 5000);
    }


    Handler mHideHandler = new Handler();
    Runnable mHideRunnable = new Runnable() {
        @Override
        public void run() {
            mSystemUiHider.hide();
        }
    };

    /**
     * Schedules a call to hide() in [delay] milliseconds, canceling any
     * previously scheduled calls.
     */
    private void delayedHide(int delayMillis) {
        mHideHandler.removeCallbacks(mHideRunnable);
        mHideHandler.postDelayed(mHideRunnable, delayMillis);
    }
    /**
     * Interface con javascript para el control del arreglo de imágenes y vídeos
     */
    public class WebAppInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        WebAppInterface(Context c) {
            mContext = c;
        }

        /** Cargar el arreglo */
        @JavascriptInterface
        public void LoadInfo(String toast) {
            ActInfo = true;
            //Toast.makeText(ActivityPublicity.this, "Carga Datos", Toast.LENGTH_SHORT).show();
            //progressBar.dismiss();
            try {
                Gson gson = new Gson();
                RankingPublicity[] rk = gson.fromJson(toast, RankingPublicity[].class);

                if (ActivityPublicity.ENTRIES != null)
                    ActivityPublicity.ENTRIES.clear();
                else
                    ActivityPublicity.ENTRIES = new ArrayList<RankingPublicity>();


                boolean DeviceAddPublicity = false;
                boolean allowadd = false;
                for (int i = 0; i < rk.length; i++) {
                    allowadd = false;
                    switch (FunctionalityTV) {
                        case 1:
                            if(!DeviceAddPublicity){
                                allowadd = isPublicityOnly(rk[i]);
                                if(allowadd) DeviceAddPublicity = true; // acepta solo un item de publicidad
                            }
                            break;
                        case 2:
                            allowadd = isPublicityOnly(rk[i]); // acepta todos los items de publicidad
                            break;
                        case 3:
                            allowadd = !isPublicityOnly(rk[i]); // acepta solo items de compartir experiencias
                            break;
                        case 4:
                            allowadd = true; // acepta todos los items
                            break;
                    }
                    if(allowadd)
                        ActivityPublicity.ENTRIES.add(rk[i]);
                }
                //eliminar de la sd los archivos que fueron borrados administrativamente antes de ser ejecutada la app
                FilesUtil.DeleteOldFiles(ActivityPublicity.this,ActivityPublicity.ENTRIES);
                ActInfo = false;
                ActivityPublicity.Index = 0;
                if(isFirtsTime) {

                    //llamar la descarga del logo
                    if(ActivityPublicity.ObjReturn.ClientLogo() != "" && ActivityPublicity.ObjReturn.ClientLogo() != null) {
                        String[] valu = new String[2];
                        valu[0] = ActivityPublicity.ObjReturn.ClientLogo();
                        DownloadLogoTask task = new DownloadLogoTask();
                        task.execute(valu);
                    }else{
                        imageLogo.setVisibility(View.GONE);
                    }
                    //-----------------------------------------------------------------

                    if(ActivityPublicity.ENTRIES.size() >0) {
                        ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).Gestionado = false;
                        //Toast.makeText(ActivityPublicity.this, "Carga Datos2", Toast.LENGTH_SHORT).show();
                        if (ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).RutaImagen == "" ||
                                ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).RutaImagen == null) {

                            String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,
                                    Double.parseDouble(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).IdRankingIdioma.toString()));
                            if (StrFile.equals("")) {
                                //comentario de este código para que no cargue el video en el visor de youtube
                                //ActivityPublicity.player.cueVideo(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).Descripcion);
                                 /*-------------------------*/
                                WaitPlayingYoutube();


                                //solicitar la descarga del video de youtube
                                RequestDonwloadVideoYoutube(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index));
                            } else {
                                GetWayVideo(StrFile);//esto indica que el archivo ya se descargo a disco
                            }
                        } else {
                            showImage(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index));
                        }
                        ActivityPublicity.Index++;
                    }else{
                        //mostrar imagen que indica que se no tiene publicidad para ser visualizada
                        NoPublicityAsign();
                    }
                    isFirtsTime = false;
                }
            }catch (Exception exception)
            {
                Toast.makeText(ActivityPublicity.this, exception.toString(), Toast.LENGTH_SHORT).show();
            }
            ActInfo = false;
        }

        @JavascriptInterface
        public void AddItem(String toast){
            ActInfo = true;
            Gson gson = new Gson();
            gson.fromJson(toast, RankingPublicity[].class);
            try {
                RankingPublicity[] rk = gson.fromJson(toast, RankingPublicity[].class);
                if(ActivityPublicity.ENTRIES == null){
                    ActivityPublicity.ENTRIES = new ArrayList<RankingPublicity>();
                }
                //si llegue a la máxima cantidad de items mostrados eliminar el item mas antiguo
                /*if( countItemsShowExperience() > CANTITEMSMAXSHARE){
                    RemoveItemFirstExperience();
                }*/
                //------------------------------------------------------------------------------

                boolean find = false;
                int j = 0;
                boolean allowadd = false;
                boolean DeviceAddPublicity = false;
                for(int i = 0;i<rk.length;i++) {

                    allowadd = false;
                    switch (FunctionalityTV) {
                        case 1:
                            if(!DeviceAddPublicity){
                                allowadd = isPublicityOnly(rk[i]);
                                if(allowadd) {
                                    DeviceAddPublicity = true; // acepta solo un item de publicidad

                                    if(ActivityPublicity.ENTRIES.size() == 1) {
                                        RankingPublicity[] rkap = new RankingPublicity[1];
                                        rkap[0] = ActivityPublicity.ENTRIES.get(0);
                                        removeItemRk(rkap);
                                    }
                                }
                            }
                            break;
                        case 2:
                            allowadd = isPublicityOnly(rk[i]); // acepta todos los items de publicidad
                            break;
                        case 3:
                            allowadd = !isPublicityOnly(rk[i]); // acepta solo items de compartir experiencias
                            break;
                        case 4:
                            allowadd = true; // acepta todos los items
                            break;
                    }

                    find = false;
                    for(j = 0; j<ActivityPublicity.ENTRIES.size(); j++){
                        if(rk[i].IdRankingIdioma.doubleValue() == ActivityPublicity.ENTRIES.get(j).IdRankingIdioma.doubleValue()){
                            find = true;
                            break;
                        }
                    }

                    if(allowadd) {
                        rk[i].Gestionado = false;
                        if (find) {
                            //validar que el archivo exista en la sd
                            String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,
                                    Double.parseDouble(ActivityPublicity.ENTRIES.get(j).IdRankingIdioma.toString()));

                            if (!StrFile.equals("")) {
                                FileStorage objStorage = new FileStorage();
                                objStorage.Id = Double.parseDouble(ActivityPublicity.ENTRIES.get(j).IdRankingIdioma.toString());
                                FilesUtil.ListItemRemove(ActivityPublicity.this, objStorage);
                            }

                            ActivityPublicity.ENTRIES.remove(j);
                            ActivityPublicity.ENTRIES.add(rk[i]);
                        } else {
                            ActivityPublicity.ENTRIES.add(rk[i]);
                        }
                    }
                }
                // si solo se esta mostrando una imagen, permitir la actualizacion
                if(ActivityPublicity.ENTRIES.size() == 1)
                    OneImageShowed = false;



                //ActivityPublicity.Index = 0;
                ActInfo = false;
            }catch (Exception exception)
            {
            }

            ActInfo = false;
        }

        @JavascriptInterface
        public void RemoveItem(String toast){
            if(!isInChangeProcess && !RemovingPendingItems) {
                ActInfo = true;
                Gson gson = new Gson();
                gson.fromJson(toast, RankingPublicity[].class);
                try {
                    RankingPublicity[] rk = gson.fromJson(toast, RankingPublicity[].class);
                    if (ActivityPublicity.ENTRIES == null) {
                        ActivityPublicity.ENTRIES = new ArrayList<RankingPublicity>();
                    }
                    removeItemRk(rk);
                    //ActivityPublicity.Index = 0;
                    ActInfo = false;

                } catch (Exception exception) {
                }
                ActInfo = false;
            }else{
                Gson gson = new Gson();
                gson.fromJson(toast, RankingPublicity[].class);
                try {
                    RankingPublicity[] rk = gson.fromJson(toast, RankingPublicity[].class);
                    if (ActivityPublicity.ENTRIES_remove == null) {
                        ActivityPublicity.ENTRIES_remove = new ArrayList<RankingPublicity>();
                    }
                    for(int i = 0;i<rk.length;i++) {
                        ActivityPublicity.ENTRIES_remove.add(rk[i]);
                    }
                } catch (Exception exception) {
                }
            }
        }
        @JavascriptInterface
        public void LostConnect() {
            Toast.makeText(ActivityPublicity.this, "Oh no! ", Toast.LENGTH_SHORT).show();
            //indica que se perdio la conexión con el servidor

            //solo lo hace cuando es un TV o es wayChannel
            if (ActivityPublicity.ObjReturn != null) {
                if (ActivityPublicity.ObjReturn.IntCode() == 2) {
                    ServerConex = false;
                    if (RtaConexServer)
                        RtaConexServer = false;
                }
            }
        }
    }
    /***************************************************************************/

    private boolean isPublicityOnly(RankingPublicity objRank){
        boolean retorno = false;
        if(objRank.RutaImagen == "" || objRank.RutaImagen == null){
            retorno = true;
        }else{
            if(objRank.TipoArchivo == 1) {
                if (objRank.Usuario == null || objRank.Usuario == "") {
                    retorno = true;
                }
            }else{
                retorno = true;
            }
        }

        return  retorno;
    }

    private boolean showTokenLogo(){
        return (FunctionalityTV ==3 || FunctionalityTV == 4);
    }

    //méotodo para remover los items pendientes por procesar
    private void RemovePendingItems(){
        if(ActivityPublicity.ENTRIES_remove != null) {
            if (ActivityPublicity.ENTRIES_remove.size() > 0) {
                RemovingPendingItems = true;
                int size = ActivityPublicity.ENTRIES_remove.size();
                for (int i = 0; i < size; i++) {
                    RankingPublicity[] rk = new RankingPublicity[1];
                    rk[0] = ActivityPublicity.ENTRIES_remove.get(i);
                    removeItemRk(rk);
                    ActivityPublicity.ENTRIES_remove.remove(i);
                }
                RemovingPendingItems = false;
            }
        }
    }
    //------------------------------------------------------

    //metodo para remover items del arreglo principal
    private void removeItemRk(RankingPublicity[] rk){
        boolean find = false;
        int j = 0;
        for (int i = 0; i < rk.length; i++) {
            find = false;
            for (j = 0; j < ActivityPublicity.ENTRIES.size(); j++) {
                if (rk[i].IdRankingIdioma.doubleValue() == ActivityPublicity.ENTRIES.get(j).IdRankingIdioma.doubleValue()) {
                    find = true;
                    break;
                }
            }
            if (find) {
                /*if (ActivityPublicity.ENTRIES.get(j).RutaImagen != "" ||
                        ActivityPublicity.ENTRIES.get(j).RutaImagen != null) {*/

                    //validar que el archivo exista en la sd
                    String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,
                            Double.parseDouble(ActivityPublicity.ENTRIES.get(j).IdRankingIdioma.toString()));

                    if(!StrFile.equals("")){
                        FileStorage objStorage = new FileStorage();
                        objStorage.Id = Double.parseDouble(ActivityPublicity.ENTRIES.get(j).IdRankingIdioma.toString());
                        FilesUtil.ListItemRemove(ActivityPublicity.this,objStorage);
                    }

                    /*if (objImage.containsKey(ActivityPublicity.ENTRIES.get(j).IdRankingIdioma.toString()))
                        objImage.remove(ActivityPublicity.ENTRIES.get(j).IdRankingIdioma.toString());*/


                //}

                ActivityPublicity.ENTRIES.remove(j);

                int itRemove = ActivityPublicity.Index - 1;
                if (itRemove == j) {
                    //indica que se removio el item que se esta mostrando
                    currentRemove = true;
                }

                if ((ActivityPublicity.Index - 1) < 0)
                    ActivityPublicity.Index = ActivityPublicity.ENTRIES.size();
                else
                    ActivityPublicity.Index--;
            }
        }
    }
    //----------------------------------------------------------------------------------------------------

    /**
     * Metodo que remueve el item mas antiguo de las experiencias que ya se han mostrado
     */
    private void RemoveItemFirstExperience(){
            RemoveInfo = true;
            int itmremove = -1;
            int itActual = ActivityPublicity.Index - 1;
            itActual = itActual < 0 ? 0 : itActual;

            for (int j = 0; j < ActivityPublicity.ENTRIES.size(); j++) {
                if (ActivityPublicity.ENTRIES.get(j).Usuario != null) {
                    if (ActivityPublicity.ENTRIES.get(j).Usuario != "" &&
                            ActivityPublicity.ENTRIES.get(j).YaSeMostroEnParrilla) {
                        if (itActual != j) {
                            itmremove = j;
                            break;
                        }
                    }
                }
            }

            if (itmremove != -1) {
                /*if (objImage.containsKey(ActivityPublicity.ENTRIES.get(itmremove).IdRankingIdioma.toString()))
                    objImage.remove(ActivityPublicity.ENTRIES.get(itmremove).IdRankingIdioma.toString());*/

                //validar que el archivo exista en la sd
                String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,
                        Double.parseDouble(ActivityPublicity.ENTRIES.get(itmremove).IdRankingIdioma.toString()));

                if(!StrFile.equals("")){
                    FileStorage objStorage = new FileStorage();
                    objStorage.Id = Double.parseDouble(ActivityPublicity.ENTRIES.get(itmremove).IdRankingIdioma.toString());
                    FilesUtil.ListItemRemove(ActivityPublicity.this,objStorage);
                }

                ActivityPublicity.ENTRIES.remove(itmremove);
                if ((ActivityPublicity.Index - 1) < 0)
                    ActivityPublicity.Index = ActivityPublicity.ENTRIES.size();
                else
                    ActivityPublicity.Index--;
            }
            RemoveInfo = false;
    }

    /**
     * Método que cuenta la cantidad de items de experiencias que ya se han mostrado
     */
    private int countItemsShowExperience(){
        int cont = 0;

        for(int j = 0; j<ActivityPublicity.ENTRIES.size(); j++){
            if(ActivityPublicity.ENTRIES.get(j).Usuario != null){
                if(ActivityPublicity.ENTRIES.get(j).Usuario != "" &&
                   ActivityPublicity.ENTRIES.get(j).YaSeMostroEnParrilla) {
                    cont++;
                }
            }
        }

        return cont;
    }

    /*************************************************************************/
    /**
     * Métodos para los efectos de cambio de imágenes y vídeos
     */
    private void showImage(RankingPublicity ObjRanking){
        String[] values = new String[4];

        values[0] = ObjRanking.RutaImagen;
        values[1] = ObjRanking.IdRankingIdioma.toString();

        if (ObjRanking.Usuario != null)
            values[2] = ObjRanking.Usuario.toString();

        if (ObjRanking.Descripcion != null)
            values[3] = ObjRanking.Descripcion.toString();


        if(ObjRanking.TipoArchivo == 1) {

            if (ImgShow == 1) {
                ActivityPublicity.image2.setImageDrawable(null);
                ActivityPublicity.image2.setImageBitmap(null);
                new DownloadImageTask((ImageView) ActivityPublicity.image2).execute(values);
            } else {
                ActivityPublicity.image.setImageBitmap(null);
                ActivityPublicity.image.setImageDrawable(null);
                new DownloadImageTask((ImageView) ActivityPublicity.image).execute(values);
            }

        }else{
            //validar que el archivo exista en la sd
            String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,Double.parseDouble(ObjRanking.IdRankingIdioma.toString()));

            if(StrFile.equals("")) {
                GetWayVideo(ObjRanking.RutaImagen);
                requestDownloadVideo(ObjRanking);
            }else
                GetWayVideo(StrFile);
        }
    }

    private class AsyncNoPublicityAsign extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            return "";
        }
        @Override
        protected void onPostExecute(String result) {
            Bitmap icon = BitmapFactory.decodeResource(ActivityPublicity.this.getResources(),
                    R.drawable.nopublicidadasignada);
            image.setImageBitmap(icon);

            if (ActivityPublicity.frameVideo.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideo.startAnimation(slideOut);
            }

            if (ActivityPublicity.frameVideoWay.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideoWay.startAnimation(slideOut);
            }


            if (ActivityPublicity.frameVideo.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideo.setVisibility(View.GONE);
                ActivityPublicity.playerView.setVisibility(View.GONE);
            }

            if (ActivityPublicity.frameVideoWay.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideoWay.setVisibility(View.GONE);
                ActivityPublicity.vidSurface.setVisibility(View.GONE);
            }

            ActivityPublicity.txtUserShare.setText("");
            ActivityPublicity.txtMenssageShare.setText("");
            ActivityPublicity.txtSiteShare.setText("");

            ActivityPublicity.slideOut.setFillAfter(true);
            ActivityPublicity.slideOut.setFillEnabled(true);
            ActivityPublicity.slide.setFillAfter(true);
            ActivityPublicity.slide.setFillEnabled(true);

            ActivityPublicity.FrameImg.setVisibility(View.VISIBLE);
            ActivityPublicity.FrameImg.startAnimation(slide);

            if(showTokenLogo())ActivityPublicity.infoWay.setVisibility(View.VISIBLE); // solo lo muestra si se comparten experiencias en el dispositivo

            ActivityPublicity.image2.setImageDrawable(null);
            ActivityPublicity.image2.setImageBitmap(null);

            if (ActivityPublicity.FrameImg2.getVisibility() == View.VISIBLE) {
                ActivityPublicity.FrameImg2.startAnimation(slideOut);
                ActivityPublicity.FrameImg2.setVisibility(View.GONE);
            }
            ImgShow = 1;
            Handler handler = new Handler(Looper.getMainLooper(),new UICallback());
            handler.sendEmptyMessageDelayed(UICallback.WAIT_IMAGE, ActivityPublicity.timeBtImages);
        }
    }
    private void NoPublicityAsign(){
        AsyncNoPublicityAsign ws = new AsyncNoPublicityAsign();
        ws.execute();
    }

    //método para realizar la descarga de un video
    private void requestDownloadVideo(RankingPublicity objRanking){
        if(!DonwloadingVideo){
            String[] spl = objRanking.RutaImagen.split("/");
            String[] params = new String[5];
            params[0] = objRanking.RutaImagen;
            params[1] = spl[spl.length - 1];
            params[2] = objRanking.IdRankingIdioma.toString();
            params[3] = objRanking.Descripcion;
            params[4] = objRanking.RutaImagen;
            DownloadVideoTask ws = new DownloadVideoTask();
            ws.execute(params);
        }
    }

    //método para realizar la descarga de un video de youtube
    private void RequestDonwloadVideoYoutube(RankingPublicity objRanking){
        if(!DonwloadingVideo) {
            //solicitar descar del video de youtube
            String[] params = new String[3];
            params[0] = objRanking.Descripcion;
            params[1] =  objRanking.IdRankingIdioma.toString();
            params[2] =  objRanking.RutaImagen;
            AsyncGetInfoVideoYoutubeWSCall wsYoutube = new AsyncGetInfoVideoYoutubeWSCall();
            wsYoutube.execute(params);
        }
    }
    /*Método que es llamado una vez es ejecutado el timer de mostrar una imágen*/
    public void getInfo(){
        //if(ActivityPublicity.Conex) {

            if (!ActInfo && !RemoveInfo && !RemovingPendingItems) {
                //variable que indica que esta en proceso de cambio
                isInChangeProcess = true;

                if(ActivityPublicity.ENTRIES.size() ==0) {
                    NoPublicityAsign();
                    isInChangeProcess = false;
                    return;
                }

                slideOut.setFillAfter(true);
                slideOut.setFillEnabled(true);
                slide.setFillAfter(true);
                slide.setFillEnabled(true);


                if (ActivityPublicity.Index < ActivityPublicity.ENTRIES.size()) {
                    //marcar como visualizado el item anterior
                    CheckViewedItem();

                    ActivityPublicity.ENTRIES.get(getIndex()).Gestionado = false;
                    if (ActivityPublicity.ENTRIES.get(getIndex()).RutaImagen == "" ||
                            ActivityPublicity.ENTRIES.get(getIndex()).RutaImagen == null) {

                        OneImageShowed = false;
                        String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,
                                Double.parseDouble(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).IdRankingIdioma.toString()));

                        if(StrFile.equals("")) {
                            //cometario de código para que no se cargue el video en el visor de youtube
                            /*ActivityPublicity.infoWay.setVisibility(View.GONE);

                            //ocultar los controles activos
                            HideControlsMain();

                            ActivityPublicity.frameVideo.startAnimation(slide);
                            ActivityPublicity.frameVideo.setVisibility(View.VISIBLE);
                            ActivityPublicity.playerView.setVisibility(View.VISIBLE);

                            ActivityPublicity.player.cueVideo(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).Descripcion);*/

                            //------------------------------------------------------------------------------------------------------
                            WaitPlayingYoutube();

                            //solicitar la descarga del video de youtube
                            RequestDonwloadVideoYoutube(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index));

                        }else{
                            this.GetWayVideo(StrFile);//esto indica que el archivo ya se descargo a disco
                        }
                    } else {
                        showImage(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index));
                    }
                } else {
                    //marcar como visualizado el item anterior
                    CheckViewedItem();

                    ActivityPublicity.Index = 0;
                    ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).Gestionado = false;
                    if (ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).RutaImagen == "" ||
                            ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).RutaImagen == null) {

                        OneImageShowed = false;

                        String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,
                                Double.parseDouble(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).IdRankingIdioma.toString()));

                        if(StrFile.equals("")) {
                            //comentario de códido para que no se muestre el vídeo en el visor de youtube
                           /* ActivityPublicity.infoWay.setVisibility(View.GONE);

                            HideControlsMain();
                            if (ActivityPublicity.frameVideo.getVisibility() == View.GONE) {
                                ActivityPublicity.frameVideo.startAnimation(slide);
                                ActivityPublicity.frameVideo.setVisibility(View.VISIBLE);
                                ActivityPublicity.playerView.setVisibility(View.VISIBLE);
                            }

                            ActivityPublicity.player.cueVideo(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index).Descripcion);*/
                            //-----------------------------------------------------------------------------------------
                            WaitPlayingYoutube();

                            //solicitar la descarga del video de youtube
                            RequestDonwloadVideoYoutube(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index));

                        }else{
                            this.GetWayVideo(StrFile);//esto indica que el archivo ya se descargo a disco
                        }
                    } else {
                        showImage(ActivityPublicity.ENTRIES.get(ActivityPublicity.Index));
                    }
                }
                ActivityPublicity.Index++;

                isInChangeProcess = false;
                // si mientras se estaba mostrando una imagen eliminaron algun item, verificar y eliminar
                RemovePendingItems();
            } else {
                int indxAux = -1;
                if(ActivityPublicity.Index >= ActivityPublicity.ENTRIES.size())
                    indxAux = ActivityPublicity.ENTRIES.size() - 1;
                else
                    indxAux = ActivityPublicity.Index;

                if(ActivityPublicity.ENTRIES.get(indxAux).TipoArchivo == 1) {
                    //si se esta actualizando la información dejar la misma imágen, según el tiempo definido en la variable timeBtImagesActInfo

                    Handler handler = new Handler(Looper.getMainLooper(),new UICallback());
                    handler.sendEmptyMessageDelayed(UICallback.WAIT_IMAGE, ActivityPublicity.timeBtImagesActInfo);

                    /*Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            getInfo();
                        }
                    }, ActivityPublicity.timeBtImagesActInfo);*/
                }else{
                    OneImageShowed = false;
                    String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,
                            Double.parseDouble(ActivityPublicity.ENTRIES.get(indxAux).IdRankingIdioma.toString()));

                    if(StrFile.equals("")) {
                        this.GetWayVideo(ActivityPublicity.ENTRIES.get(indxAux).RutaImagen);
                        requestDownloadVideo(ActivityPublicity.ENTRIES.get(indxAux));
                    }else
                        this.GetWayVideo(StrFile);
                }
            }
        //}
    }

    private int getIndex(){
        return (ActivityPublicity.Index > ActivityPublicity.ENTRIES.size())?0:ActivityPublicity.Index;
    }


    //método para marcar un item como ya visto
    private void CheckViewedItem(){
        int checkItem = ActivityPublicity.Index - 1;
        if(checkItem <0){
            checkItem = ActivityPublicity.ENTRIES.size() - 1;
        }
        ActivityPublicity.ENTRIES.get(checkItem).YaSeMostroEnParrilla = true;

        //si llegue a la máxima cantidad de items mostrados eliminar el item mas antiguo
        if( countItemsShowExperience() > CANTITEMSMAXSHARE){
            RemoveItemFirstExperience();
        }
    }

    private void HideControlsMain (){

        ActivityPublicity.txtUserShare.setText("");
        ActivityPublicity.txtMenssageShare.setText("");
        ActivityPublicity.txtSiteShare.setText("");

        if (ActivityPublicity.FrameImg.getVisibility() == View.VISIBLE) {
            ActivityPublicity.image.setImageBitmap(null);
            ActivityPublicity.image.setImageDrawable(null);
            ActivityPublicity.FrameImg.startAnimation(slideOut);
            ActivityPublicity.FrameImg.setVisibility(View.GONE);
        }


        if (ActivityPublicity.FrameImg2.getVisibility() == View.VISIBLE) {
            ActivityPublicity.image2.setImageBitmap(null);
            ActivityPublicity.image2.setImageDrawable(null);
            ActivityPublicity.FrameImg2.startAnimation(slideOut);
            ActivityPublicity.FrameImg2.setVisibility(View.GONE);
        }
        if (ActivityPublicity.frameVideoWay.getVisibility() == View.VISIBLE) {
            ActivityPublicity.frameVideoWay.startAnimation(slideOut);
            ActivityPublicity.frameVideoWay.setVisibility(View.GONE);
            ActivityPublicity.vidSurface.setVisibility(View.GONE);
        }
    }

    /*Método para la descargar del logo del cliente*/
    private class DownloadLogoTask extends AsyncTask<String, Void, Bitmap> {

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];

            Bitmap mIconLogo = null;
            try {
                InputStream inLogo = (InputStream)new java.net.URL(urldisplay).openStream();
                mIconLogo = BitmapFactory.decodeStream(inLogo);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIconLogo;
        }

        protected void onPostExecute(Bitmap result) {
            if(result != null) {
                imageLogo.setImageBitmap(result);
                imageLogo.setVisibility(View.VISIBLE);
            }else{
                Toast.makeText(ActivityPublicity.this, "Imagen de logo del cliente con errores", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //método para obtener las imagenes antes de que termine un video, para evitar que se demore en cargar
    private void GetImageBefore(RankingPublicity ObjRanking) {
        String[] values = new String[4];

        values[0] = ObjRanking.RutaImagen;
        values[1] = ObjRanking.IdRankingIdioma.toString();

        if (ObjRanking.Usuario != null)
            values[2] = ObjRanking.Usuario.toString();

        if (ObjRanking.Descripcion != null)
            values[3] = ObjRanking.Descripcion.toString();

        if (ObjRanking.RutaImagen != "" && ObjRanking.RutaImagen != null) {
            new DownloadImageOnly().execute(values);
        }
    }
    //clase para descargar la imagen al dispositivo sin mostrarla aun
    private class DownloadImageOnly extends AsyncTask<String, Void, String> {
        String User;
        String Description;

        protected String doInBackground(String... urls) {
            String urldisplay = urls[0];

            String KeyVI = "";
            if(urls[1] != null && urls[1] != "")
                KeyVI = urls[1];

            if(urls[2] != null && urls[2] != "")
                this.User =urls[2];

            if(urls[3] != null && urls[3] != "")
                this.Description =urls[3];

            try {
                String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,
                        Double.parseDouble(KeyVI));
                if(StrFile.equals("")){
                    //InputStream in = new java.net.URL(urldisplay).openStream();
                    String[] split = urldisplay.split("/");
                    String rtn = DownloadFiles.DonwLoadFile(ActivityPublicity.this,
                            urldisplay,
                            split[split.length - 1],
                            Double.parseDouble(KeyVI),
                            urldisplay,
                            this.Description);
                }
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(Bitmap result) {

        }
    }

    /*Método que ejecuta la descarga de las imágenes del servidor y las presenta en la aplicación*/
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;
        String User;
        String Description;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];

            String KeyVI = "";
            if(urls[1] != null && urls[1] != "")
                KeyVI = urls[1];

            if(urls[2] != null && urls[2] != "")
                this.User =urls[2];

            if(urls[3] != null && urls[3] != "")
                this.Description =urls[3];

            Bitmap mIcon11 = null;

            try {
                if(!OneImageShowed || ActivityPublicity.ENTRIES.size() >1) {
                    String StrFile = FilesUtil.ItemExist(ActivityPublicity.this,
                            Double.parseDouble(KeyVI));
                    if (!StrFile.equals("")) {
                        mIcon11 = FilesUtil.GetFileImage(StrFile);
                    } else {
                        //InputStream in = new java.net.URL(urldisplay).openStream();
                        String[] split = urldisplay.split("/");
                        String rtn = DownloadFiles.DonwLoadFile(ActivityPublicity.this,
                                urldisplay,
                                split[split.length - 1],
                                Double.parseDouble(KeyVI),
                                urldisplay,
                                this.Description);
                        if (!rtn.equals("")) {
                            mIcon11 = FilesUtil.GetFileImage(rtn);
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(final Bitmap result) {
            if(ActivityPublicity.ENTRIES.size() == 1){
                if(!OneImageShowed)
                    OneImageShowed = true;
                else {
                    SendChangeImg();
                    return;
                }
            }else
                OneImageShowed = false;

            ActivityPublicity.ENTRIES.get(ActivityPublicity.Index - 1).Gestionado = true;
            //si el result es null indica que  no se logro descargar la imagen
            if(result != null) {
                try {
                    bmImage.setImageBitmap(result);

                    ActivityPublicity.slideOut.setFillAfter(true);
                    ActivityPublicity.slideOut.setFillEnabled(true);
                    ActivityPublicity.slide.setFillAfter(true);
                    ActivityPublicity.slide.setFillEnabled(true);


                    if (showTokenLogo())
                        ActivityPublicity.infoWay.setVisibility(View.VISIBLE); // solo lo muestra si se comparten experiencias en el dispositivo

                    if (this.User == null || this.User == "") {
                        //llamar al contador de publicidad
                        countObj.Add(1);
                        //---------------------------------
                        ActivityPublicity.txtUserShare.setText("");
                        ActivityPublicity.txtMenssageShare.setText("");
                        ActivityPublicity.txtSiteShare.setText("");
                        bmImage.setScaleType(ImageView.ScaleType.FIT_XY);
                    } else {
                        if (this.Description == null) this.Description = "";

                        String[] Spli = this.User.split("\\|");
                        if (this.Description.trim().equals("")) {
                            ActivityPublicity.txtUserShare.setText("Compartido por: " + Spli[0]);
                            ActivityPublicity.txtMenssageShare.setText("");
                            ActivityPublicity.txtMenssageShare.setTextSize(TypedValue.COMPLEX_UNIT_SP, 0);
                        } else {
                            ActivityPublicity.txtUserShare.setText(Spli[0] + " dice:");
                            ActivityPublicity.txtMenssageShare.setText(this.Description.trim());
                            ActivityPublicity.txtMenssageShare.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
                        }

                        if (Spli.length == 1) {
                            ActivityPublicity.txtSiteShare.setText("");
                            txtSiteShare.setVisibility(View.GONE);
                        } else {
                            txtSiteShare.setVisibility(View.VISIBLE);
                            ActivityPublicity.txtSiteShare.setText(Spli[1]);
                        }

                        bmImage.setScaleType(ImageView.ScaleType.FIT_CENTER);

                    }

                    if (ImgShow == 1) {
                        ActivityPublicity.FrameImg2.setVisibility(View.VISIBLE);
                        ActivityPublicity.FrameImg2.startAnimation(slide);
                        ActivityPublicity.FrameImg.startAnimation(slideOut);

                        hideControlsSlideOut(false);
                        HideControls();

                        ActivityPublicity.FrameImg.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                result.recycle();
                                System.gc();
                                ActivityPublicity.image.setImageDrawable(null);
                                ActivityPublicity.image.setImageBitmap(null);
                                ActivityPublicity.FrameImg.setVisibility(View.GONE);
                                SendChangeImg();
                            }
                        }, timeAnimation);

                        ImgShow = 2;
                    } else {
                        ActivityPublicity.FrameImg.setVisibility(View.VISIBLE);
                        ActivityPublicity.FrameImg.startAnimation(slide);
                        ActivityPublicity.FrameImg2.startAnimation(slideOut);

                        hideControlsSlideOut(false);
                        HideControls();

                        ActivityPublicity.FrameImg.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                result.recycle();
                                System.gc();
                                ActivityPublicity.image2.setImageDrawable(null);
                                ActivityPublicity.image2.setImageBitmap(null);

                                if (ActivityPublicity.FrameImg2.getVisibility() == View.VISIBLE) {

                                    ActivityPublicity.FrameImg2.setVisibility(View.GONE);
                                }

                                SendChangeImg();
                            }
                        }, timeAnimation);

                        ImgShow = 1;
                    }
                } catch (Exception e) {
                    getInfo();
                }
            }else{
                getInfo();
            }

        }

        private void SendChangeImg(){
            Handler handler = new Handler(Looper.getMainLooper(),new UICallback());
            handler.sendEmptyMessageDelayed(UICallback.WAIT_IMAGE, ActivityPublicity.timeBtImages);

            /*Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    getInfo();
                }
            }, ActivityPublicity.timeBtImages );*/
        }

        private void hideControlsSlideOut(boolean isShareContentCall){
            if (ActivityPublicity.frameVideo.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideo.startAnimation(slideOut);
            }

            if (ActivityPublicity.frameVideoWay.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideoWay.startAnimation(slideOut);
            }
        }

        private void HideControls(){
            if (ActivityPublicity.frameVideo.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideo.setVisibility(View.GONE);
                ActivityPublicity.playerView.setVisibility(View.GONE);
            }

            if (ActivityPublicity.frameVideoWay.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideoWay.setVisibility(View.GONE);
                ActivityPublicity.vidSurface.setVisibility(View.GONE);
            }

        }
    }

    /****************************************************************************/

    /**
     * Métodos para el manejo de Youtube
     */
    private void WaitPlayingYoutube(){
        //Se lanza un timer esperando x número de segundos para validar si el video inicio, si no
        //debe generarse el ciclo de nuevo, ya que cuando se presenta publicidad el video no incia

        Handler handler = new Handler(Looper.getMainLooper(),new UICallback());
        handler.sendEmptyMessageDelayed(UICallback.WAIT_PLAYING_VIDEO_YOUTUBE, ActivityPublicity.timeWaitBeginYoutube);
    }

    @Override
    protected YouTubePlayer.Provider getYouTubePlayerProvider() {
        return (YouTubePlayerView) findViewById(R.id.player);
    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer player,
                                        boolean wasRestored) {
        this.player = player;

        player.setPlayerStateChangeListener(playerStateChangeListener);
        player.setPlaybackEventListener(playbackEventListener);

        // Specify that we want to handle fullscreen behavior ourselves.
        player.addFullscreenControlFlag(YouTubePlayer.FULLSCREEN_FLAG_CUSTOM_LAYOUT);

        /*if (!wasRestored) {
            if(this.ENTRIES != null) {
                if(this.ENTRIES.size()>0) {
                    player.cueVideo(this.ENTRIES.get(this.Index).Descripcion);
                    WaitPlayingYoutube();
                    this.Index++;
                }
            }
        }*/
    }
    /*Clase para el manejo de los eventos del control de youtube*/
    private final class MyPlaybackEventListener implements PlaybackEventListener {
        String playbackState = "NOT_PLAYING";
        String bufferingState = "";
        @Override
        public void onPlaying() {
            playbackState = "PLAYING";
        }

        @Override
        public void onBuffering(boolean isBuffering) {
            bufferingState = isBuffering ? "(BUFFERING)" : "";
        }

        @Override
        public void onStopped() {
            playbackState = "STOPPED";
        }

        @Override
        public void onPaused() {
            playbackState = "PAUSED";
        }

        @Override
        public void onSeekTo(int endPositionMillis) {
        }
    }
    /*Clase para el manejo de los eventos del control de youtube*/
    private final class MyPlayerStateChangeListener implements PlayerStateChangeListener {
        String playerState = "UNINITIALIZED";

        @Override
        public void onLoading() {
            playerState = "LOADING";
        }

        @Override
        public void onLoaded(String videoId) {
            playerState = String.format("LOADED %s", videoId);
            player.play();
        }

        @Override
        public void onAdStarted() {
            playerState = "AD_STARTED";
        }

        @Override
        public void onVideoStarted() {
            playerState = "VIDEO_STARTED";
        }

        @Override
        public void onVideoEnded() {
            playerState = "VIDEO_ENDED";
            if(!currentRemove) {
                if (!ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado) {
                    ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado = true;
                    getInfo();
                }
            }else{
                // indica que el item que se removio fue el que se esta mostrando
                currentRemove = false;
                getInfo();
            }
            //ValidateInfoYoutube();
        }

        @Override
        public void onError(ErrorReason reason) {
            playerState = "ERROR (" + reason + ")";
            if (reason == ErrorReason.UNEXPECTED_SERVICE_DISCONNECTION) {
                // When this error occurs the player is released and can no longer be used.
                player = null;
            }
        }
    }

    /**********************************************************************************************************/

    /**
     * Método timer para la validación de la conexión a red y al servidor
     */
    final Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if(loadUrlAgain){
                loadUrlAgain = false;
                Map<String, String> extraHeaders = new HashMap<String, String>();
                extraHeaders.put("Referer", "http://www.WayReferer.tld/main.html");

                webView.loadUrl(ActivityPublicity.ObjReturn.StrMenssage() +"&PUTY=" + FunctionalityTV, extraHeaders);
                //indica que es un tv
                if (ActivityPublicity.ObjReturn.IntCode() == 2) {
                    delayedHide(100);
                }


            }
            if (!validateServer) {
                validateServer = true;
                AsyncGetIsOnLine objA = new AsyncGetIsOnLine();
                objA.execute();
            }

            if (conMgr.getActiveNetworkInfo() != null) {
                if (!Conex) {
                    ActivityPublicity.txtMsgRed.setVisibility(View.GONE);
                    ActivityPublicity.webView.setVisibility(View.VISIBLE);
                    if(showTokenLogo())ActivityPublicity.infoWay.setVisibility(View.VISIBLE); // solo lo muestra si se comparten experiencias en el dispositivo

                    if (ObjReturn == null) {
                        GetWorkInfo();
                    } else {
                        Map<String, String> extraHeaders = new HashMap<String, String>();
                        extraHeaders.put("Referer", "http://www.WayReferer.tld/main.html");

                        webView.loadUrl(ActivityPublicity.ObjReturn.StrMenssage() +"&PUTY=" + FunctionalityTV, extraHeaders);
                        //indica que es un tv
                        if (ActivityPublicity.ObjReturn.IntCode() == 2) {
                            delayedHide(100);
                        }
                    }
                    Conex = true;
                }
            } else if (conMgr.getActiveNetworkInfo() == null) {
                if (Conex) {
                    /*ActivityPublicity.txtMsgRed.setVisibility(View.VISIBLE);
                    ActivityPublicity.webView.setVisibility(View.GONE);
                    ActivityPublicity.frameVideo.setVisibility(View.GONE);
                    ActivityPublicity.playerView.setVisibility(View.GONE);
                    ActivityPublicity.frameVideoWay.setVisibility(View.GONE);
                    ActivityPublicity.vidSurface.setVisibility(View.GONE);
                    ActivityPublicity.FrameImg.setVisibility(View.GONE);
                    ActivityPublicity.FrameImg2.setVisibility(View.GONE);
                    ActivityPublicity.infoWay.setVisibility(View.GONE);*/
                    Conex = false;
                    //se setea esta variable a verdadero  para volver a cargar las imágenes
                    isFirtsTime = true;
                }
            }

            //rutina para mostrar el mensaje que invita a acceder a waysites

            //-fin de la rutina
            return false;
        }
    });

    //timer
    private class ConexTask extends TimerTask {
        @Override
        public void run() {
            mHandler.sendEmptyMessage(0);
        }
    }
    /**********************************************************************************************

    /********************************************************************************************/
    /**
     * Metodo para validar que exista conexión con el servidor
     */
    private class AsyncGetIsOnLine extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            if (ActivityPublicity.ObjReturn != null) {
                try {
                    ConnectivityManager cm = (ConnectivityManager) ActivityPublicity.this

                            .getSystemService(Context.CONNECTIVITY_SERVICE);

                    if (cm.getActiveNetworkInfo().isConnectedOrConnecting()) {

                        URL url = new URL(ActivityPublicity.ObjReturn.StrMenssage());
                        HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
                        urlc.setConnectTimeout(3000); // mTimeout is in seconds

                        urlc.connect();

                        if (urlc.getResponseCode() == 200) {
                            // si 5 veces retorno como caida la página indica que realmente esta caida
                            if(!RtaConexServer && ContConexFail >=12) {
                                RtaConexServer = true;

                                if (ObjReturn == null) {
                                    GetWorkInfo();
                                } else {
                                    loadUrlAgain = true;
                                }
                            }else{
                                RtaConexServer = true;
                                ContConexFail = 0;
                            }
                        } else {
                            //contador de las veces que se presenta un error al consultar la pagina
                            ContConexFail++;
                            RtaConexServer = false;
                        }
                        validateServer = false;
                    }
                } catch (IOException e) {
                    // Esta excepcion se puede presentar si el servidor esta caido y no esta respondiendo
                    RtaConexServer = false;
                    validateServer = false;
                    //contador de las veces que se presenta un error al consultar la pagina
                    ContConexFail++;
                    ActivityPublicity.rslt = e.getMessage();
                } catch (Exception exception) {
                    RtaConexServer = false;
                    validateServer = false;
                    //contador de las veces que se presenta un error al consultar la pagina
                    ContConexFail++;
                    ActivityPublicity.rslt = exception.getMessage();
                }
            }
            validateServer = false;
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
        }
    }
    /********************************************************************************************/
    private void GetWorkInfo(){
        //SharedPreferences sharedPref = ActivityPublicity.this.getSharedPreferences(ActivityPublicity.this.getString(R.string.app_name), Context.MODE_PRIVATE);

        SharedPreferences sharedPref = null;
        if(con != null) {
            sharedPref = con.getSharedPreferences(
                    getString(R.string.app_name), Context.MODE_PRIVATE);
        }else{
            sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
        }

        if (sharedPref.getString("objInfoConect", "") != "") {
            Gson gson = new Gson();
            ObjReturn =  gson.fromJson(sharedPref.getString("objInfoConect", ""), ReturnInfo.class);

            timeBtImages = ObjReturn.TiempoSlidePublicidadP();

            txtWayToken.setText(ActivityPublicity.ObjReturn.WayToken());

            Map<String, String> extraHeaders = new HashMap<String, String>();
            extraHeaders.put("Referer", "http://www.WayReferer.tld/main.html");

            webView.loadUrl(ActivityPublicity.ObjReturn.StrMenssage()+"&PUTY=" + FunctionalityTV, extraHeaders);
            //indica que es un tv
            if (ActivityPublicity.ObjReturn.IntCode() == 2) {
                setFullScreen();
            }
        }

    }
    /**
     * Métodos para el manejo de videos alojados en el servidor de WAY
     */
    @Override
    public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
        // TODO Auto-generated method stub
    }

    @Override
    public void surfaceCreated(SurfaceHolder arg0) {
        String a;
        a = "";
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder arg0) {
        // TODO Auto-generated method stub
    }

    private void WaitPlayingVideoWayServer(){
        //Se lanza un timer esperando x número de segundos para validar si el video inicio, si no
        //debe generarse el ciclo de nuevo, ya que cuando se presenta publicidad el video no incia
        Handler handler = new Handler(Looper.getMainLooper(),new UICallback());
        handler.sendEmptyMessageDelayed(UICallback.WAIT_PLAYING_VIDEO_WAY_SERVER, ActivityPublicity.timeWaitBeginYoutube);
       /* handler.postDelayed(new Runnable() {
            public void run() {
                if(mediaPlayer != null) {
                    if (!mediaPlayer.isPlaying())
                        getInfo();
                }
            }
        }, ActivityPublicity.timeWaitBeginYoutube);*/
    }

    private final class UICallback implements Handler.Callback{
        public static final int WAIT_PLAYING_VIDEO_WAY_SERVER = 0;
        public static final int WAIT_PLAYING_VIDEO_YOUTUBE = 1;
        public static final int WAIT_IMAGE = 2;
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case UICallback.WAIT_PLAYING_VIDEO_WAY_SERVER: {
                    if(mediaPlayer != null) {
                        if (!mediaPlayer.isPlaying()) {
                            if(!currentRemove) {
                                if (!ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado) {
                                    ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado = true;
                                    getInfo();
                                }
                            }else{
                                currentRemove = false;
                                getInfo();
                            }
                        }else{
                            //llamar el contador de publicidad, ya que se logro mostrar el video
                            countObj.Add(1);
                            //------------------------------------------------------------------

                            //obtener la imagen una vez se inicie el video
                            int indexTmp = ActivityPublicity.Index;
                            if (indexTmp >= ActivityPublicity.ENTRIES.size()) {
                                indexTmp = 0;
                            }
                            GetImageBefore(ActivityPublicity.ENTRIES.get(indexTmp));
                        }
                    }else{
                        getInfo();
                    }
                    return true;
                }
                case UICallback.WAIT_PLAYING_VIDEO_YOUTUBE:{
                    if(!player.isPlaying())
                        if(!currentRemove) {
                            if (!ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado) {
                                ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado = true;
                                getInfo();
                            }
                        }else{
                            currentRemove = false;
                            getInfo();
                        }
                    else {
                        //llamar el contador de publicidad, ya que se logro mostrar el video
                        countObj.Add(1);
                        //------------------------------------------------------------------
                        //obtener la imagen una vez se inicie el video
                        int itIndexTmp = ActivityPublicity.Index;
                        if (itIndexTmp >= ActivityPublicity.ENTRIES.size()) {
                            itIndexTmp = 0;
                        }
                        GetImageBefore(ActivityPublicity.ENTRIES.get(itIndexTmp));
                    }
                    return true;
                }
                case UICallback.WAIT_IMAGE:{
                    boolean CallInfo = true;
                    if(mediaPlayer != null) {
                        if (mediaPlayer.isPlaying()){
                            CallInfo = false;
                        }
                    }
                    if(player != null) {
                        if (player.isPlaying()) {
                            CallInfo = false;
                        }
                    }
                    if(CallInfo)
                        getInfo();

                    return true;
                }
                default:
                    return false;
            }
        }
    }

    public class MyService extends AsyncTask<String, Void, Void> implements MediaPlayer.OnPreparedListener {
        private boolean boolerror;
        @Override
        protected Void doInBackground(String... params) {
            boolerror = false;
            if(mediaPlayer != null){
                mediaPlayer.release();
                mediaPlayer = null;
            }

            try {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                mediaPlayer.setDisplay(vidHolder);
                mediaPlayer.setDataSource(params[0]);
                mediaPlayer.prepareAsync();
                mediaPlayer.setOnPreparedListener(this);
                mediaPlayer.setOnErrorListener(new OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        if(mediaPlayer != null) {
                            if (!mediaPlayer.isPlaying()) {
                                boolerror = true;
                                //Toast.makeText(ActivityPublicity.this, "Oh no! Error", Toast.LENGTH_SHORT).show();
                                mediaPlayer.release();
                                mediaPlayer = null;
                                ActivityPublicity.frameVideoWay.startAnimation(slideOut);
                                ActivityPublicity.frameVideoWay.setVisibility(View.GONE);
                                ActivityPublicity.vidSurface.setVisibility(View.GONE);
                                if(!currentRemove) {
                                    if (!ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado) {
                                        ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado = true;
                                        getInfo();
                                    }
                                }else{
                                    currentRemove = false;
                                    getInfo();
                                }
                            }
                        }
                        return false;
                    }
                });

                mediaPlayer.setOnCompletionListener(new OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        if(!boolerror) {
                            mediaPlayer.release();
                            mediaPlayer = null;
                            ActivityPublicity.frameVideoWay.startAnimation(slideOut);
                            ActivityPublicity.frameVideoWay.setVisibility(View.GONE);
                            ActivityPublicity.vidSurface.setVisibility(View.GONE);
                            if(!currentRemove) {
                                if (!ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado) {
                                    ActivityPublicity.ENTRIES.get((ActivityPublicity.Index - 1) < 0 ? 0 : (ActivityPublicity.Index - 1)).Gestionado = true;
                                    getInfo();
                                }
                            }else{
                                currentRemove = false;
                                getInfo();
                            }
                        }
                    }
                });
            }
            catch(Exception e){
                /*if(mediaPlayer != null) {
                    if (!mediaPlayer.isPlaying()) {
                        if (!ActivityPublicity.ENTRIES.get(ActivityPublicity.Index - 1).Gestionado) {
                            ActivityPublicity.ENTRIES.get(ActivityPublicity.Index - 1).Gestionado = true;
                            getInfo();
                        }
                    }
                }*/
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {

            ActivityPublicity.slideOut.setFillAfter(true);
            ActivityPublicity.slideOut.setFillEnabled(true);
            ActivityPublicity.slide.setFillAfter(true);
            ActivityPublicity.slide.setFillEnabled(true);
            ActivityPublicity.infoWay.setVisibility(View.GONE);
            ActivityPublicity.frameVideoWay.startAnimation(slide);
            ActivityPublicity.frameVideoWay.setVisibility(View.VISIBLE);
            ActivityPublicity.vidSurface.setVisibility(View.VISIBLE);

            if (ActivityPublicity.frameVideo.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideo.startAnimation(slideOut);
                ActivityPublicity.frameVideo.setVisibility(View.GONE);
                ActivityPublicity.playerView.setVisibility(View.GONE);
            }

            if (ActivityPublicity.FrameImg.getVisibility() == View.VISIBLE) {
                ActivityPublicity.FrameImg.startAnimation(slideOut);
                ActivityPublicity.FrameImg.setVisibility(View.GONE);
            }
            if (ActivityPublicity.FrameImg2.getVisibility() == View.VISIBLE) {
                ActivityPublicity.FrameImg2.startAnimation(slideOut);
                ActivityPublicity.FrameImg2.setVisibility(View.GONE);
            }

            //lanzar un temporizador que valida si se ejecuto el video o no, o si no continuar el ciclo
            WaitPlayingVideoWayServer();
        }
        @Override
        public void onPrepared(MediaPlayer mp) {
            mediaPlayer.start();
        }
    }

    private void GetWayVideo(String Url){
        OneImageShowed = false;
        String[] prm = new String[1];
        prm[0] = Url;
        CallExecVideo wexc = new CallExecVideo();
        wexc.execute(prm);
    }

    public class CallExecVideo extends AsyncTask<String, Void, String> {
        String Url = "";
        @Override
        protected String doInBackground(String... params) {
            Url = params[0];
            return "";
        }
        @Override
        protected void onPostExecute(String result) {
            ActivityPublicity.slideOut.setFillAfter(true);
            ActivityPublicity.slideOut.setFillEnabled(true);
            ActivityPublicity.slide.setFillAfter(true);
            ActivityPublicity.slide.setFillEnabled(true);
            ActivityPublicity.infoWay.setVisibility(View.GONE);
            ActivityPublicity.frameVideoWay.startAnimation(slide);
            ActivityPublicity.frameVideoWay.setVisibility(View.VISIBLE);
            ActivityPublicity.vidSurface.setVisibility(View.VISIBLE);

            if (ActivityPublicity.frameVideo.getVisibility() == View.VISIBLE) {
                ActivityPublicity.frameVideo.startAnimation(slideOut);
                ActivityPublicity.frameVideo.setVisibility(View.GONE);
                ActivityPublicity.playerView.setVisibility(View.GONE);
            }

            if (ActivityPublicity.FrameImg.getVisibility() == View.VISIBLE) {
                ActivityPublicity.FrameImg.startAnimation(slideOut);
                ActivityPublicity.FrameImg.setVisibility(View.GONE);
            }
            if (ActivityPublicity.FrameImg2.getVisibility() == View.VISIBLE) {
                ActivityPublicity.FrameImg2.startAnimation(slideOut);
                ActivityPublicity.FrameImg2.setVisibility(View.GONE);
            }

            ActivityPublicity.txtUserShare.setText("");
            ActivityPublicity.txtMenssageShare.setText("");
            ActivityPublicity.txtSiteShare.setText("");
            ActivityPublicity.image.setImageDrawable(null);
            ActivityPublicity.image.setImageBitmap(null);
            ActivityPublicity.image2.setImageDrawable(null);
            ActivityPublicity.image2.setImageBitmap(null);

            ActivityPublicity.frameVideoWay.setVisibility(View.VISIBLE);
            ActivityPublicity.vidSurface.setVisibility(View.VISIBLE);
            String[] values = new String[1];
            values[0] = Url;
            new MyService().execute(values);
        }
    }

    /*******************************************************************************************/

    /*---------------------------------- ocultar el mensaje de invitar a waysites --------------------*/
    Handler mHideInvitation = new Handler();
    Runnable mHideRunnableInvitation = new Runnable() {
        @Override
        public void run() {
            InvitationOut.setFillAfter(true);
            InvitationOut.setFillEnabled(true);
            txtMsgInvitation.startAnimation(InvitationOut);
            txtMsgInvitation.setVisibility(View.GONE);
        }
    };

    private void delayedHideInvitation(int delayMillis) {
        mHideInvitation.removeCallbacks(mHideRunnableInvitation);
        mHideInvitation.postDelayed(mHideRunnableInvitation, delayMillis);
    }

    /*-------------------------------------------------------------------------------------------------*/

    //métodos para la descarga de archivos de video
    private class AsyncGetInfoVideoYoutubeWSCall extends AsyncTask<String, Void, AnswerAction> {
        String fileId = "";
        String Description = "";
        String RutaImgOriginal = "";
        @Override
        protected AnswerAction doInBackground(String... params) {
            fileId = params[1];
            Description = params[0];
            RutaImgOriginal = params[2];
            return DownloadFiles.ObtenerInfoVideoYoutube(params[0]);
        }
        @Override
        protected void onPostExecute(AnswerAction result) {

            if(result.error != 99){
                if(!DonwloadingVideo) {
                    String[] params = new String[5];
                    params[0] = result.Mensaje;
                    params[1] = result.FileName;
                    params[2] = fileId;
                    params[3] = Description;
                    params[4] = RutaImgOriginal;
                    DownloadVideoTask ws = new DownloadVideoTask();
                    ws.execute(params);
                }
            }else{
                Log.e("ErrorVideoY","Error-" + result.Mensaje);
            }
        }
        @Override
        protected void onPreExecute() {
        }
    }


    private class DownloadVideoTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            DonwloadingVideo = true;
            String urldisplay = urls[0];
            String nombreArchivo = urls[1];
            String IdFile = urls[2];
            Double idF = Double.parseDouble(IdFile);
            String DescriptionOriginal = urls[3];
            String RutaOriginal = urls[4];
            String retorno = "";
            try {
                //InputStream in = new java.net.URL(urldisplay).openStream();
                retorno =  DownloadFiles.DonwLoadFile(ActivityPublicity.this,
                        urldisplay,
                        nombreArchivo,
                        idF,
                        RutaOriginal,
                        DescriptionOriginal);
            } catch (Exception e) {
                DonwloadingVideo = false;
                Log.e("Error DImageT", e.getMessage());
                e.printStackTrace();
            }
            return retorno;
        }

        @Override
        protected void onPostExecute(String Valor) {
            DonwloadingVideo = false;
        }

        @Override
        protected void onPreExecute() {
        }
    }

    //------------------------------------------------------------------------------------------------------
}
