package com.WayViewer.waysurveyviewer.app.BusinessObjects;

/**
 * Created by Manuel on 14/07/2014.
 */
public class ReturnInfo {
    private int _intError;
    private int _intCode;
    private String _wayToken;
    private String _strMenssage;
    private String _strClientLogo;
    private short IdTipoPublicidad;
    private long IdSucursal;
    private int TiempoSlidePublicidad;
    public ReturnInfo(){}
    public ReturnInfo(int interror,
                      int intCode,
                      String strMens,
                      String strwayToken,
                      String strClientLogo,
                      short IdTipoPublicidadI,
                      long IdSucursalI,
                      int TiempoSlidePublicidadI){
        this._intCode = intCode;
        this._intError = interror;
        this._strMenssage = strMens;
        this._wayToken = strwayToken;
        this._strClientLogo = strClientLogo;
        this.IdTipoPublicidad = IdTipoPublicidadI;
        this.IdSucursal = IdSucursalI;
        this.TiempoSlidePublicidad = TiempoSlidePublicidadI;
    }

    public int IntError(){
        return this._intError;
    }
    public void IntError(int interror){
        this._intError = interror;
    }

    public int IntCode(){
        return this._intCode;
    }
    public void IntCode(int intcode){
        this._intCode = intcode;
    }

    public String StrMenssage(){
        return this._strMenssage;
    }
    public void StrMenssage(String strmen){
        this._strMenssage = strmen;
    }

    public String WayToken(){
        return this._wayToken;
    }

    public void WayToken(String strWayToken){
        this._wayToken = strWayToken;
    }

    public String ClientLogo(){
        return this._strClientLogo;
    }

    public void ClientLogo(String strClientLogo){
        this._strClientLogo = strClientLogo;
    }

    public void IdTipoPublicidadP(short IdTipoPublicidadI){
        this.IdTipoPublicidad = IdTipoPublicidadI;
    }

    public short IdTipoPublicidadP(){
        return this.IdTipoPublicidad;
    }

    public void IdSucursalP(long IdSucursalI){
        this.IdSucursal = IdSucursalI;
    }

    public long IdSucursalP(){
        return this.IdSucursal;
    }

    public void TiempoSlidePublicidadP(int TiempoSlidePublicidadI){
        this.TiempoSlidePublicidad = TiempoSlidePublicidadI;
    }

    public int TiempoSlidePublicidadP(){
        return this.TiempoSlidePublicidad;
    }
}
