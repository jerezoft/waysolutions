package com.WayViewer.waysurveyviewer.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.ReturnInfo;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


public class BootConexWait extends ActionBarActivity {
    private Timer timer = new Timer();
    ConnectivityManager conMgr;
    private boolean Conex = true;
    public static String rslt="";
    public static ReturnInfo ObjReturn;

    private class ConexTask extends TimerTask {
        @Override
        public void run() {
            mHandler.sendEmptyMessage(0);
        }
    }
    final Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if(conMgr == null) {
                conMgr =
                        (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            }
            NetworkInfo activeNetwork = conMgr.getActiveNetworkInfo();
            if (activeNetwork != null &&
                    activeNetwork.isConnectedOrConnecting()) {
                timer.cancel();
                Conex = true;
                /*SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                if (sharedPref.getString("RegisterID", "") != "") {
                    Intent start_i = new Intent(BootConexWait.this, WayViewerSurvey.class);
                    start_i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(start_i);
                } else {*/
                    Intent start_i = new Intent(BootConexWait.this, WaySurveyMain.class);
                    start_i.putExtra("activity","BootConexWait");
                    start_i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(start_i);
                //}
                finish(); // Call once you redirect to another activity
            }

            return false;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boot_conex_wait);
        timer = new Timer();
        timer.schedule(new ConexTask(), 0,500);
    }
}
