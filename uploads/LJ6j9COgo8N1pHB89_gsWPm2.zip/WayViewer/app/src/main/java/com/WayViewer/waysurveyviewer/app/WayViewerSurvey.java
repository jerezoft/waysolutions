package com.WayViewer.waysurveyviewer.app;

import android.annotation.TargetApi;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.os.Handler.Callback;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.DeviceType;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.ReturnInfo;
import com.WayViewer.waysurveyviewer.app.R;
import com.WayViewer.waysurveyviewer.app.util.SystemUiHider;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import WebServices.CallWebServices;
import java.util.Timer;
import java.util.TimerTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Handler.Callback;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.PluginState;
import 	java.net.URL;
import 	java.net.HttpURLConnection;
import 	java.io.IOException;
/*import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.ResponseHandler;
import org.apache.http.impl.client.BasicResponseHandler;*/
import android.view.WindowManager;

public class WayViewerSurvey extends ActionBarActivity {
    private WebView webview;
    private static final String TAG = "WayViewerSurvey";
    private ProgressDialog progressBar;
    private ProgressDialog progressBarWeb;

    /**
     * Whether or not the system UI should be auto-hidden after
     * {@link #AUTO_HIDE_DELAY_MILLIS} milliseconds.
     */
    private static final boolean AUTO_HIDE = true;

    /**
     * If {@link #AUTO_HIDE} is set, the number of milliseconds to wait after
     * user interaction before hiding the system UI.
     */
    private static final int AUTO_HIDE_DELAY_MILLIS = 3000;

    /**
     * If set, will toggle the system UI visibility upon interaction. Otherwise,
     * will show the system UI visibility upon interaction.
     */
    private static final boolean TOGGLE_ON_CLICK = true;

    /**
     * The flags to pass to {@link SystemUiHider#getInstance}.
     */
    private static final int HIDER_FLAGS = SystemUiHider.FLAG_HIDE_NAVIGATION;

    /**
     * The instance of the {@link SystemUiHider} for this activity.
     */
    private SystemUiHider mSystemUiHider;

    public static String rslt = "";
    public static ReturnInfo ObjReturn;
    private AlertDialog alertDialog;
    private TextView txtMsgRed;
    private boolean Conex = true;
    private boolean ServerConex = true;
    private boolean validateServer = false;
    private boolean RtaConexServer = false;

    private Timer timer = new Timer();
    ConnectivityManager conMgr;
    private static int SenderAct = 1;

    final Handler mHandler = new Handler(new Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (!ServerConex) {
                if (!RtaConexServer) {
                    if (!validateServer) {
                        validateServer = true;
                        AsyncGetIsOnLine objA = new AsyncGetIsOnLine();
                        objA.execute();
                    }
                } else {
                    if (ObjReturn == null) {
                        AsyncGetINWSCall objAsync = new AsyncGetINWSCall();
                        objAsync.execute();
                    } else {
                        Map<String, String> extraHeaders = new HashMap<String, String>();
                        extraHeaders.put("Referer", "http://www.WayReferer.tld/main.html");
                        //esta línea permite que se visualicen los videos
                        webview.setWebChromeClient(new WebChromeClient() {
                        });
                        webview.loadUrl(WayViewerSurvey.ObjReturn.StrMenssage(), extraHeaders);
                        //indica que es un tv
                        if (WayViewerSurvey.ObjReturn.IntCode() == 2) {
                            delayedHide(100);
                        }
                    }
                    ServerConex = true;
                    RtaConexServer = false;
                    validateServer = false;
                }
            }
            if (conMgr.getActiveNetworkInfo() != null) {
                if (!Conex) {
                    txtMsgRed.setVisibility(View.GONE);
                    webview.setVisibility(View.VISIBLE);
                    if (ObjReturn == null) {
                        AsyncGetINWSCall objAsync = new AsyncGetINWSCall();
                        objAsync.execute();
                    } else {
                        Map<String, String> extraHeaders = new HashMap<String, String>();
                        extraHeaders.put("Referer", "http://www.WayReferer.tld/main.html");
                        //esta línea permite que se visualicen los videos
                        webview.setWebChromeClient(new WebChromeClient() {
                        });
                        webview.loadUrl(WayViewerSurvey.ObjReturn.StrMenssage(), extraHeaders);
                        //indica que es un tv
                        if (WayViewerSurvey.ObjReturn.IntCode() == 2) {
                            delayedHide(100);
                        }
                    }
                    Conex = true;
                }
            } else if (conMgr.getActiveNetworkInfo() == null) {
                if (Conex) {
                    txtMsgRed.setVisibility(View.VISIBLE);
                    webview.setVisibility(View.GONE);
                    Conex = false;
                }
            }
            return false;
        }
    });


    private class ConexTask extends TimerTask {
        @Override
        public void run() {
            mHandler.sendEmptyMessage(0);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_way_viewer_survey);

        conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        txtMsgRed = (TextView) findViewById(R.id.TxtConex);
        txtMsgRed.setVisibility(View.GONE);

        this.webview = (WebView) findViewById(R.id.Wview1);
        //this.webview.setWebChromeClient(new WebChromeClient());
        WebSettings settings = webview.getSettings();
        settings.setJavaScriptEnabled(true);
        //settings.setCacheMode(settings.LOAD_NO_CACHE);
        settings.setAppCacheEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setPluginState(PluginState.ON);
        settings.setDatabasePath("/data/data/" + getPackageName() + "/databases");
        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 16) {
            settings.setMediaPlaybackRequiresUserGesture(false);
        }
        settings.setPluginState(PluginState.ON);


        webview.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);

        webview.addJavascriptInterface(new WebAppInterface(this), "MSSAndroidFunction");

        alertDialog = new AlertDialog.Builder(this).create();

        progressBarWeb = ProgressDialog.show(WayViewerSurvey.this, "WaySurvey", "Cargando...");

        webview.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.i(TAG, "Processing webview url click...");
                view.loadUrl(url);
                return true;
            }

            public void onPageFinished(WebView view, String url) {
                Log.i(TAG, "Finished loading URL: " + url);
                if (progressBarWeb.isShowing()) {
                    progressBarWeb.dismiss();
                }
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e(TAG, "Error: " + description);
                Toast.makeText(WayViewerSurvey.this, "Oh no! " + description, Toast.LENGTH_SHORT).show();
                //indica que se perdio la conexión con el servidor
                if (errorCode == -6) {
                    //solo lo hace cuando es un TV o es wayChannel
                    if (WayViewerSurvey.ObjReturn != null) {
                        if (WayViewerSurvey.ObjReturn.IntCode() == 2) {
                            ServerConex = false;
                            if(RtaConexServer)
                                RtaConexServer = false;
                        }
                    }
                }
                //alertDialog.setTitle("Error");
                //alertDialog.setMessage(description);
                //alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                //    public void onClick(DialogInterface dialog, int which) {
                //        return;
                //    }
                //});
                //alertDialog.show();
            }
        });

        AsyncGetINWSCall objAsync = new AsyncGetINWSCall();
        objAsync.execute();
    }

    public class WebAppInterface {
        Context mContext;
        public String m_szTagId;
        public String szDate;
        /**
         * Instantiate the interface and set the context
         */
        WebAppInterface(Context c) {
            mContext = c;
        }

        /**
         * Cargar el arreglo
         */
        @JavascriptInterface
        public void openDatePickerDialog(String szTagId) {
            m_szTagId = szTagId;

            Calendar c = Calendar.getInstance();
            DatePickerDialog dp = new DatePickerDialog(mContext, new DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year,
                                      int monthOfYear, int dayOfMonth) {
                    szDate = String.format("%04d/%02d/%02d", year, monthOfYear + 1, dayOfMonth);

                    webview.post(new Runnable() {
                        @Override
                        public void run() {
                            webview.loadUrl("javascript:callFromActivity_RetDate('" + m_szTagId + "', '" + szDate + "')");
                        }
                    });
                }
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
            dp.show();
        }
    }

    private void setFullScreen() {
        final View contentView = findViewById(R.id.Wview1);

        // Set up an instance of SystemUiHider to control the system UI for
        // this activity.
        mSystemUiHider = SystemUiHider.getInstance(this, contentView, HIDER_FLAGS);
        mSystemUiHider.setup();
        mSystemUiHider
                .setOnVisibilityChangeListener(new SystemUiHider.OnVisibilityChangeListener() {
                    @Override
                    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
                    public void onVisibilityChange(boolean visible) {
                        if (visible && AUTO_HIDE) {
                            // Schedule a hide().
                            delayedHide(AUTO_HIDE_DELAY_MILLIS);
                        }
                    }
                });

        // Set up the user interaction to manually show or hide the system UI.
        contentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TOGGLE_ON_CLICK) {
                    mSystemUiHider.toggle();
                } else {
                    mSystemUiHider.show();
                }
            }
        });

        delayedHide(100);

        //validar conexion a red
        timer = new Timer();
        timer.schedule(new ConexTask(), 0, 500);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        // Trigger the initial hide() shortly after the activity has been
        // created, to briefly hint to the user that UI controls
        // are available.
        if (WayViewerSurvey.ObjReturn != null) {
            if (WayViewerSurvey.ObjReturn.IntCode() == 2) {
                delayedHide(100);
            }
        }
    }

    Handler mHideHandler = new Handler();
    Runnable mHideRunnable = new Runnable() {
        @Override
        public void run() {
            mSystemUiHider.hide();
        }
    };

    /**
     * Schedules a call to hide() in [delay] milliseconds, canceling any
     * previously scheduled calls.
     */
    private void delayedHide(int delayMillis) {
        mHideHandler.removeCallbacks(mHideRunnable);
        mHideHandler.postDelayed(mHideRunnable, delayMillis);
    }


    private class AsyncGetINWSCall extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            CallWebServices cso = new CallWebServices();

            String android_id = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ANDROID_ID);

            String serialnum = null;
            WifiManager wifiManager = (WifiManager) WayViewerSurvey.this.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wifiManager.getConnectionInfo();
            serialnum = info.getMacAddress();

            if (serialnum != null) {
                android_id += serialnum;
            }

            SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);

            cso.IngresoAplicacion(sharedPref.getString("RegisterID", ""),
                    android_id,WayViewerSurvey.SenderAct
            );
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            if (WayViewerSurvey.ObjReturn != null) {
                if (WayViewerSurvey.ObjReturn.IntCode() == 0 || WayViewerSurvey.ObjReturn.IntError() != 0) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage(WayViewerSurvey.ObjReturn.StrMenssage());
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            progressBarWeb.dismiss();
                            finish();
                            return;
                        }
                    });
                    alertDialog.show();
                } else {
                    //agregar el waytoken en las preferencias
                    if(WayViewerSurvey.ObjReturn.WayToken() != null){
                        if(WayViewerSurvey.ObjReturn.WayToken() != "") {
                            SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPref.edit();
                            editor.putString("WayToken", WayViewerSurvey.ObjReturn.WayToken());
                            editor.commit();
                        }
                    }

                    Map<String, String> extraHeaders = new HashMap<String, String>();
                    extraHeaders.put("Referer", "http://www.WayReferer.tld/main.html");
                    if (WayViewerSurvey.ObjReturn.IntCode() == 2) {
                        //esta línea permite que se visualicen los videos
                        webview.setWebChromeClient(new WebChromeClient() {
                            @Override
                            public void onConsoleMessage(String message, int lineNumber,
                                                         String sourceID) {
                                super.onConsoleMessage(message, lineNumber, sourceID);
                                Log.i("VIDEO VIEW", message);
                            }
                        });
                    }
                    webview.loadUrl(WayViewerSurvey.ObjReturn.StrMenssage(), extraHeaders);
                    //indica que es un tv
                    if (WayViewerSurvey.ObjReturn.IntCode() == 2) {
                        setFullScreen();
                    }
                }
            } else {
                if (WayViewerSurvey.rslt != "") {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage(WayViewerSurvey.rslt);
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            progressBarWeb.dismiss();
                            finish();
                            return;
                        }
                    });
                    alertDialog.show();
                }
            }
            progressBar.dismiss();
        }

        @Override
        protected void onPreExecute() {
            progressBar = ProgressDialog.show(WayViewerSurvey.this, "", "Procesando...");
        }
    }

    private class AsyncGetIsOnLine extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            if (WayViewerSurvey.ObjReturn != null) {
                try {
                    ConnectivityManager cm = (ConnectivityManager) WayViewerSurvey.this

                            .getSystemService(Context.CONNECTIVITY_SERVICE);

                    if (cm.getActiveNetworkInfo().isConnectedOrConnecting()) {

                        URL url = new URL(WayViewerSurvey.ObjReturn.StrMenssage());
                        HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
                        urlc.setConnectTimeout(1000); // mTimeout is in seconds

                        urlc.connect();
/*                    String SetServerString = "";

                    HttpClient Client = new DefaultHttpClient();
                    HttpGet httpget = new HttpGet("http://www.google.com/");
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    SetServerString = Client.execute(httpget, responseHandler);*/

                        if (urlc.getResponseCode() == 200) {
                            RtaConexServer = true;
                        } else {
                            RtaConexServer = false;
                        }
                        validateServer = false;
                    }
                } catch (IOException e) {
                    // Esta excepcion se puede presentar si el servidor esta caido y no esta respondiendo
                    RtaConexServer = false;
                    validateServer = false;
                    WayViewerSurvey.rslt = e.getMessage();
                } catch (Exception exception) {
                    RtaConexServer = false;
                    validateServer = false;
                    WayViewerSurvey.rslt = exception.getMessage();
                }
            }
            validateServer = false;
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
        }
    }
}
