package com.WayViewer.waysurveyviewer.app.Utilities;

import android.app.Activity;
import android.util.Log;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.AnswerAction;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by hp on 15/03/2016.
 */
public class DownloadFiles {
    public static AnswerAction ObtenerInfoVideoYoutube(String VideoID){
        AnswerAction objRt = new AnswerAction();
        String retorno = "";
        try {
            JSONHttpClient ObjGenericCall = new JSONHttpClient();
            Map<String, Object> params = new LinkedHashMap<>();
            params.put("video_id", VideoID);
            objRt = ObjGenericCall.CallString("http://www.youtube.com/get_video_info",
                    params,
                    null,
                    "GET");

            if (objRt.error != 99) {
                Map<String, Object> paramsYoutube = ObtainValuesQueryString(objRt.Mensaje);
                if (paramsYoutube.get("reason") != null) {
                    objRt.error = 99;
                    objRt.Mensaje = paramsYoutube.get("reason").toString();
                } else {
                    objRt = GetUrlValidFormats(paramsYoutube);
                    if(objRt.error != 99){
                        // objRt.Mensaje = encodeUrl(objRt.Mensaje);
                    }
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            Log.e("executeCall", "ErrorClient URL - Exception : " + e.getMessage(), e);
        }

        return objRt;
    }

    private static  Map<String, Object> ObtainValuesQueryString(String Valores){
        Map<String, Object> params = new LinkedHashMap<>();
        try {
            String[] split = Valores.split("&");
            String llave = "";
            String valor = "";
            for (int i = 0; i < split.length; i++) {
                String[] spl = split[i].split("=");

                if(spl.length==2){
                    llave = spl[0];
                    valor =  spl[1];
                }else{
                    llave = spl[0];
                    valor = "";
                }

                params.put(llave, valor);
            }
        }  catch (Exception e) {
            e.printStackTrace();
            Log.e("executeCall", "ErrorClient URL - Exception : " + e.getMessage(), e);
        }
        return params;
    }

    private static String encodeUrl(String Valor){
        String[] split = Valor.split("&");
        StringBuilder retorno = new StringBuilder();
        try {
            for (int i = 0; i < split.length; i++) {
                String[] split1 = split[i].split("=");
                if (split1.length > 1) {
                    retorno.append(split1[0]);
                    retorno.append("=");
                    retorno.append(URLEncoder.encode(split1[1], "UTF-8"));
                }
            }
        }  catch (Exception e) {
            e.printStackTrace();
            Log.e("executeCall", "ErrorClient URL - Exception : " + e.getMessage(), e);
        }
        return retorno.toString();
    }

    private static AnswerAction GetUrlValidFormats(Map<String, Object> videoParams){
        AnswerAction objRt = new AnswerAction();
        String Retorno = "";
        boolean FileFind = false;
        try {
            if(videoParams.get("length_seconds") != null) {
                String second = videoParams.get("length_seconds").toString();
                if (Float.parseFloat(second) < 650) { // solo videos menores a 10 minutos
                    String[] videoURLs = URLDecoder.decode(videoParams.get("url_encoded_fmt_stream_map").toString(), "UTF-8").split(",");

                    for (int i = 0; i < videoURLs.length; i++) {
                        String sURL = videoURLs[i];
                        Map<String, Object> urlParams = ObtainValuesQueryString(sURL);
                        String videoFormat = URLDecoder.decode(urlParams.get("type").toString(), "UTF-8");

                        if (videoFormat.toLowerCase().contains("mp4")) {
                            String videoTitle = URLDecoder.decode((videoParams.get("title") != null ? videoParams.get("title") : "Test").toString(),"UTF-8");
                            String videoFormt = URLDecoder.decode(urlParams.get("type").toString(), "UTF-8");
                            videoFormt = videoFormt.split(";")[0].split("/")[1];

                            /*Retorno = URLDecoder.decode((urlParams.get("url") != null ? urlParams.get("url") : "").toString(), "UTF-8");
                            Retorno += "&signature=" + URLDecoder.decode((urlParams.get("sig") != null ? urlParams.get("sig") : "").toString(), "UTF-8");
                            Retorno += "&type=" + videoFormat;
                            Retorno += "&title=" + URLDecoder.decode((videoParams.get("title") != null ? videoParams.get("title") : "").toString(), "UTF-8");*/

                            Retorno = URLDecoder.decode((urlParams.get("url") != null ? urlParams.get("url") : "").toString(), "UTF-8");
                            Retorno += "&signature=" + (urlParams.get("sig") != null ? urlParams.get("sig") : "").toString();
                            Retorno += "&type=" + URLEncoder.encode(videoFormat,"UTF-8");
                            Retorno += "&title=" + (videoParams.get("title") != null ? videoParams.get("title") : "").toString();

                            objRt.FileName = videoTitle + "." + videoFormt;
                            objRt.error = 0;
                            objRt.Mensaje = Retorno;
                            FileFind = true;
                            break;
                        }
                    }

                    if (!FileFind) {
                        objRt.error = 99;
                        objRt.Mensaje = "No existe un formato valido para ser descargado";
                        Log.i("executeCall", "ErrorClient URL - Exception : No existe un formato valido para ser descargado");
                    }
                }else{
                    objRt.error = 99;
                    Log.i("executeCall", "ErrorClient URL - Exception : El vídeo no indica un tiempo de duración, no sera descargado");
                }
            }else{
                objRt.error = 99;
                Log.i("executeCall", "ErrorClient URL - Exception : No existe un formato valido para ser descargado");
            }
        }  catch (Exception e) {
            objRt.error = 99;
            objRt.Mensaje = "Se ha presentando un error";
            e.printStackTrace();
            Log.e("executeCall", "ErrorClient URL - Exception : " + e.getMessage(), e);
        }
        return objRt;
    }

    public static String DonwLoadFile(Activity act,
                                      String Url,
                                      String Narchivo,
                                      double FileId,
                                      String RutaArchivoOriginal,
                                      String DescripcionOriginal){
        JSONHttpClient ObjGenericCall = new JSONHttpClient();
        return ObjGenericCall.SaveAndDownloadFile(act,Url,Narchivo,FileId,RutaArchivoOriginal,DescripcionOriginal);
    }

}
