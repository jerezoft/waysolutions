package com.WayViewer.waysurveyviewer.app.Utilities;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Message;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.MensajeRespuesta;
import com.WayViewer.waysurveyviewer.app.R;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Handler;

/**
 * Created by hp on 19/03/2016.
 */
public class Counter {
    private static Activity act;
    private static boolean isActualiz = false;
    private static int PendingHits = 0;
    public static void setActivity(Activity actIn){ act =actIn;}
    public static boolean GetIsActualization() {return isActualiz;}
    private  Timer timer = new Timer();
    private String UrlServer = "";

    public Counter(String Url,Activity actIn){
        //Enviar los hits al servidor
        UrlServer = Url;
        act =actIn;
        timer = new Timer();
        timer.schedule(new ConexTask(), 0, GeneralUtilities.GetTimeActualizInfoServer(act));
    }

    public void Add( int hits){
        if(act == null) return;
        if(!isActualiz) {
            isActualiz = true;
            SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
            String Ht = sharedPref.getString("itemsCount", "");
            int cont = 0;
            if (!Ht.equals("")) cont = Integer.parseInt(Ht);

            cont += hits + PendingHits;
            PendingHits = 0;
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString("itemsCount", String.valueOf(cont));
            editor.commit();
            isActualiz = false;
        }else{
            PendingHits++;
        }
    }

    private void SendHitsToServer(){
        if(act == null) return;
        if(isActualiz) return;

        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        String Ht = sharedPref.getString("itemsCount", "");
        if(Ht.equals("") || Ht.equals("0") ) return;
        String Params[] = new String[3];
        Params[0] =sharedPref.getString("RegisterID","");
        Params[1] =Ht;
        Params[2] =UrlServer;
        SendHits ws = new SendHits();
        ws.execute(Params);
    }

    private class SendHits extends AsyncTask<String, Void, MensajeRespuesta>{
        @Override
        protected MensajeRespuesta doInBackground(String... params) {
            isActualiz = true;
            Map<String, Object> paramsws = new LinkedHashMap<>();
            paramsws.put("idDispositivo", params[0]);
            paramsws.put("cantidadHits", params[1]);

            JSONHttpClient ObjGenericCall = new JSONHttpClient();

            MensajeRespuesta retorno =  ObjGenericCall.CallObject( params[2],
                    MensajeRespuesta.class, paramsws,
                    act.getResources().getString(R.string.usuarioApp) + ":" + act.getResources().getString(R.string.passwordApp),
                    "GET");
            if(retorno == null){
                retorno = new MensajeRespuesta();
                retorno.IntError = 99;
                retorno.Mensaje =  act.getResources().getString(R.string.Generic_error);
            }
            return retorno;
        }
        @Override
        protected void onPostExecute(MensajeRespuesta result) {
            if(result.IntError == 1) {
                SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("itemsCount", String.valueOf(PendingHits));
                editor.commit();
                PendingHits = 0;
            }
            isActualiz = false;
        }
    }

    //timer
    private class ConexTask extends TimerTask {
        @Override
        public void run() {
            mHandler.sendEmptyMessage(0);
        }
    }
    /**********************************************************************************************/

    final android.os.Handler mHandler = new android.os.Handler(new android.os.Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if(!isActualiz) SendHitsToServer();
            return false;
        }
    });

}
