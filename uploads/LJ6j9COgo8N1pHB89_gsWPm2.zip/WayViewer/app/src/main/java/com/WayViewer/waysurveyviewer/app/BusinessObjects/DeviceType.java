package com.WayViewer.waysurveyviewer.app.BusinessObjects;

/**
 * Created by Manuel on 14/07/2014.
 */
public class DeviceType {
    private long _id;
    private String _descript;

    public DeviceType(long id,String descript){
        this._id = id;
        this._descript = descript;
    }

    public long Id(){
        return this._id;
    }
    public void Id(int id){
        this._id = id;
    }

    public String  Descript(){
        return this._descript;
    }
    public void Descript(String Descript){
        this._descript = Descript;
    }

}
