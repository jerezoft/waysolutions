package com.WayViewer.waysurveyviewer.app.Utilities;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.util.Log;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.FileStorage;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.RankingPublicity;
import com.WayViewer.waysurveyviewer.app.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;

/**
 * Created by hp on 15/03/2016.
 */
public class FilesUtil {
    public static final int TYPE_FILE_IMG = 1;
    public static final int TYPE_FILE_VIDEO = 2;
    public static ArrayList<FileStorage> StorageList;
    public static Bitmap GetFileImage(String RutaArchivo){
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeFile(RutaArchivo);
        }catch (Exception e) {
            Log.e("tag", e.getMessage());
        }
        return bitmap;
    }

    public static FileStorage ListItemAdd(Activity act, FileStorage ObjFile,InputStream iS){
        ObjFile = CreateFile(iS,ObjFile, act);

        if(ObjFile.Error != 99) {
            SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
            Gson gson = new Gson();
            if (sharedPref.getString("objListItemStorage", "").equals("")) {
                StorageList = new ArrayList<FileStorage>();
            } else {
                Type listType = new TypeToken<ArrayList<FileStorage>>() {
                }.getType();
                StorageList = gson.fromJson(sharedPref.getString("objListItemStorage", ""), listType);
            }

            boolean find = false;
            int i = 0;
            for (i = 0; i < StorageList.size(); i++) {
                if (StorageList.get(i).Id == ObjFile.Id) {
                    find = true;
                    break;
                }
            }
            if (!find) {
                StorageList.add(ObjFile);
            }else{
                if(DeleteFile(StorageList.get(i))) { //borrar el archivo de disco
                    StorageList.remove(i);
                    StorageList.add(ObjFile);
                }
            }

            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString("objListItemStorage", gson.toJson(StorageList));
            editor.commit();
        }
        return ObjFile;
    }

    public static void ListItemRemove(Activity act, FileStorage ObjFile){
        Gson gson = new Gson();
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        if (sharedPref.getString("objListItemStorage", "").equals("")) {
            StorageList = new ArrayList<FileStorage>();
        }else{
            Type listType = new TypeToken<ArrayList<FileStorage>>() {}.getType();
            StorageList = gson.fromJson(sharedPref.getString("objListItemStorage", ""), listType);
        }

        int i =0;
        boolean find = false;
        for(i =0;i<StorageList.size();i++){
            if(StorageList.get(i).Id == ObjFile.Id){
                find = true;
                break;
            }
        }
        if(find) {
            if(DeleteFile(StorageList.get(i))) { //borrar el archivo de disco
                StorageList.remove(i);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("objListItemStorage", gson.toJson(StorageList));
                editor.commit();
            }
        }
    }

    public static void ClearFiles(Activity act){
        File dir = new File(GetDirectorySave(act)
                + "//LapinSites//LapinSitesFiles");
        if (dir.isDirectory())
        {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++)
            {
                new File(dir, children[i]).delete();
            }
        }
    }

    public static void ClearList(Activity act){
        setStorageList(act);
        FileStorage objStore = new FileStorage();
        for(int i =0;i<StorageList.size();i++){
            if(DeleteFile(StorageList.get(i)))
                StorageList.remove(i);
        }
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("objListItemStorage", "");
        editor.commit();
    }

    //método para borrar los archivos que no se encuentran en el listado de imagenes
    public static void DeleteNoFilesInList(Activity act){

        String str_SaveFolderNameBS = GetDirectorySave(act)
                + "//LapinSites//LapinSitesFiles";

        File BSDirectory = new File(str_SaveFolderNameBS);
        if (!BSDirectory.exists())
            return;

            setStorageList(act);

        String[] files = BSDirectory.list();
        boolean find = false;
        File file;
        for(int i = 0;i <files.length;i++){
            find = false;
            for(int j =0;j<StorageList.size();j++){
                if(StorageList.get(j).NombreArchivo.trim().equals(files[i].trim())){
                    find = true;
                    break;
                }
            }
            if(!find){
                String DeleteFile = GetDirectorySave(act)
                        + "//LapinSites//LapinSitesFiles//" +files[i];
                file = new File(DeleteFile);
                if(file.exists())
                    file.delete();
            }
        }
    }

    public static void DeleteOldFiles(Activity act,ArrayList<RankingPublicity> ListRanking){
        if(ListRanking.size() ==0){
            ClearList(act);
            return;
        }
        setStorageList(act);
        boolean find = false;
        for(int i =0;i<StorageList.size();i++){
            find = false;
            if(StorageList.get(i).RutaArchivoOrigen == null) StorageList.get(i).RutaArchivoOrigen = "";
            if(StorageList.get(i).DescripcionOrigen == null) StorageList.get(i).DescripcionOrigen = "";
            for(int j=0;j<ListRanking.size();j++){
                if(StorageList.get(i).Id>0){
                    if(ListRanking.get(j).RutaImagen == null)ListRanking.get(j).RutaImagen = "";
                    if(ListRanking.get(j).Descripcion == null) ListRanking.get(j).Descripcion = "";
                    if(StorageList.get(i).Id == ListRanking.get(j).IdRankingIdioma &&
                            StorageList.get(i).RutaArchivoOrigen.trim().equals(ListRanking.get(j).RutaImagen.trim()) &&
                            StorageList.get(i).DescripcionOrigen.trim().equals(ListRanking.get(j).Descripcion.trim())){
                        find = true;
                        break;
                    }
                }
            }
            if(!find){
                if(DeleteFile(StorageList.get(i))) {
                    StorageList.remove(i);
                    i--;
                }
            }
        }
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        Gson gson = new Gson();
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("objListItemStorage", gson.toJson(StorageList));
        editor.commit();
    }

    public static boolean ListExists(Activity act){
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        return !sharedPref.getString("objListItemStorage", "").equals("");
    }

    private static void setStorageList(Activity act){
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        Gson gson = new Gson();
        if (sharedPref.getString("objListItemStorage", "").equals("")) {
            StorageList = new ArrayList<FileStorage>();
        }else{
            Type listType = new TypeToken<ArrayList<FileStorage>>() {}.getType();
            StorageList = gson.fromJson(sharedPref.getString("objListItemStorage", ""), listType);
        }
    }

    public static String ItemExist(Activity act,double IdStorage){
        setStorageList(act);
        String Retorno = "";
        boolean find = false;
        int i = 0;
        for(i =0;i<StorageList.size();i++){
            if(StorageList.get(i).Id == IdStorage){
                Retorno = StorageList.get(i).RutaArchivo;
                find = true;
                break;
            }
        }

        if(find) {
            if (!FileExists(StorageList.get(i))){
                ListItemRemove(act,StorageList.get(i));
                Retorno = "";
            }
        }

        return  Retorno;
    }
    private static boolean FileExists(FileStorage ObjStorage){
        boolean retorno = false;
        try {
            // delete the original file
            File file = new File(ObjStorage.RutaArchivo);
            retorno = file.exists();
        }
        catch (Exception e) {
            Log.e("tag", e.getMessage());
        }
        return retorno;
    }

    private static boolean DeleteFile(FileStorage ObjStorage){
        boolean retorno = false;
        try {
            // delete the original file
            File file = new File(ObjStorage.RutaArchivo);
            if(file.exists())
                file.delete();

            retorno = true;
        }
        catch (Exception e) {
            Log.e("tag", e.getMessage());
        }
        return retorno;
    }
    private static FileStorage CreateFile(InputStream iS,FileStorage ObjStorage, Activity act){
        boolean retorno = true;
        try {
            ObjStorage.NombreArchivo = ObjStorage.NombreArchivo.replaceAll("\"","");
            ObjStorage.NombreArchivo = ObjStorage.NombreArchivo.replaceAll("[^a-zA-Z0-9.]+","");
            byte[] buffer = new byte[1024];
            BufferedInputStream inStream = new BufferedInputStream(iS, 1024 * 10);
            //iS.read(buffer);

            String str_SaveFolderNameBS = GetDirectorySave(act)
                    + "//LapinSites";

            File BSDirectory = new File(str_SaveFolderNameBS);
            if (!BSDirectory.exists())
                BSDirectory.mkdirs();

            String str_SaveFolderName = GetDirectorySave(act)
                    + "//LapinSites//LapinSitesFiles";

            File wallpaperDirectory = new File(str_SaveFolderName);

            if (!wallpaperDirectory.exists())
                wallpaperDirectory.mkdirs();


            File targetFile = new File(wallpaperDirectory.getPath()+"//"+ ObjStorage.NombreArchivo);

            int read = 0;
            OutputStream outStream = new FileOutputStream(targetFile);

            while ((read = inStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, read);
            }
            outStream.close();
            inStream.close();
            iS.close();

            ObjStorage.RutaArchivo = GetDirectorySave(act)
                    + "//LapinSites//LapinSitesFiles//" +ObjStorage.NombreArchivo;
        }
        catch (Exception e) {
            ObjStorage.Error = 99;
            ObjStorage.MsgError = "Se ha presentado un error y la solicitud no pudo ser atendida";
            Log.e("UT-CRF-Error", e.getMessage());
            e.printStackTrace();
        }
        return  ObjStorage;
    }

    private static String GetDirectorySave(Activity act){
        if (android.os.Environment.getExternalStorageState().equals(
                android.os.Environment.MEDIA_MOUNTED)){
            return Environment
                    .getExternalStorageDirectory()
                    .getAbsolutePath();

        }else{
            return act.getCacheDir().getAbsolutePath();
        }
    }

}
