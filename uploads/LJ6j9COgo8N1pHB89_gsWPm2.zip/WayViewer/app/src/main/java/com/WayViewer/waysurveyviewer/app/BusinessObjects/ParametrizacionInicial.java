package com.WayViewer.waysurveyviewer.app.BusinessObjects;

/**
 * Created by hp on 22/03/2016.
 */
public class ParametrizacionInicial extends MensajeSalida {
    public String UrlBase;
    public String UrlBaseTwo;
    public int TiempoActualizacionDispositivo;
}
