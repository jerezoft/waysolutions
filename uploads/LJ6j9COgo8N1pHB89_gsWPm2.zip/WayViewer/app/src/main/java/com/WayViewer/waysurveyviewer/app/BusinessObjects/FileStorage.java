package com.WayViewer.waysurveyviewer.app.BusinessObjects;

/**
 * Created by hp on 15/03/2016.
 */
public class FileStorage {
    public double Id;
    public int TipoArchivo;
    public String NombreArchivo;
    public String RutaArchivo;
    public String RutaArchivoOrigen;
    public String DescripcionOrigen;
    public int Error;
    public String MsgError;
}
