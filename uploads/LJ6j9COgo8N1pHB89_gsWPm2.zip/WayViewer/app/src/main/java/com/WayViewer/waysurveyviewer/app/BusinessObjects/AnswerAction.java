package com.WayViewer.waysurveyviewer.app.BusinessObjects;

/**
 * Created by hp on 15/03/2016.
 */
public class AnswerAction {
    public int error;
    public String Mensaje;
    public String FileName;
}
