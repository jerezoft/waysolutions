package com.WayViewer.waysurveyviewer.app.BusinessObjects;

/**
 * Created by hp on 22/03/2016.
 */
public class MensajeRespuesta {
    public int IntError;
    public String Mensaje;
}
