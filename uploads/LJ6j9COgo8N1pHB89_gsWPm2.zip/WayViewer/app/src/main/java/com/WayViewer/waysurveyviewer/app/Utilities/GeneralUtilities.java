package com.WayViewer.waysurveyviewer.app.Utilities;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.ParametrizacionInicial;
import com.WayViewer.waysurveyviewer.app.R;
import com.google.gson.Gson;

/**
 * Created by hp on 22/03/2016.
 */
public class GeneralUtilities {
    public static void SaveParametrization(Activity act, ParametrizacionInicial objParametrization){
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        Gson gson = new Gson();
        editor.putString("ParametrizationInfo", gson.toJson(objParametrization));
        editor.commit();
    }

    public static boolean ParametrizationExists(Activity act){
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        return !sharedPref.getString("ParametrizationInfo", "").equals("");
    }

    public static String GetUrlWebservices(Activity act){
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        String Rtn = sharedPref.getString("ParametrizationInfo", "");
        if(!Rtn.equals("")){
            Gson gson = new Gson();
            return gson.fromJson(sharedPref.getString("ParametrizationInfo", ""), ParametrizacionInicial.class).UrlBase;
        }
        return "";
    }

    public static String GetUrlNotification(Activity act){
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        String Rtn = sharedPref.getString("ParametrizationInfo", "");
        if(!Rtn.equals("")){
            Gson gson = new Gson();
            return gson.fromJson(sharedPref.getString("ParametrizationInfo", ""), ParametrizacionInicial.class).UrlBaseTwo;
        }
        return "";
    }

    public static int GetTimeActualizInfoServer(Activity act){
        SharedPreferences sharedPref = act.getSharedPreferences(act.getString(R.string.app_name), Context.MODE_PRIVATE);
        String Rtn = sharedPref.getString("ParametrizationInfo", "");
        if(!Rtn.equals("")){
            Gson gson = new Gson();
            return gson.fromJson(sharedPref.getString("ParametrizationInfo", ""), ParametrizacionInicial.class).TiempoActualizacionDispositivo;
        }
        return Integer.valueOf(act.getString(R.string.DefaultTimeActualizInfo).toString());
    }
}
