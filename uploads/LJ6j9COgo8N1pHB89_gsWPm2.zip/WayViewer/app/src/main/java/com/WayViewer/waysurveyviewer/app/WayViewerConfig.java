package com.WayViewer.waysurveyviewer.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.opengl.Visibility;
import android.os.AsyncTask;
import android.provider.Settings;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.provider.Settings.Secure;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.content.DialogInterface;

import WebServices.CallWebServices;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.widget.Spinner;

import com.WayViewer.waysurveyviewer.app.BusinessObjects.ClienteLapinTv;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.DeviceType;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.MensajeSalida;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.ParametrizacionInicial;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.ReturnInfo;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.SpinerAdapterDeviceType;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.SucursalLapinTv;
import com.WayViewer.waysurveyviewer.app.Utilities.GeneralUtilities;
import com.WayViewer.waysurveyviewer.app.Utilities.Services;
import com.google.gson.Gson;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.ArrayList;

import android.net.wifi.WifiManager;
import android.net.wifi.WifiInfo;


public class WayViewerConfig extends ActionBarActivity {

    public static String rslt="";
    private EditText EDKey;
    private EditText EDdescript;
    private EditText EDuser;
    private EditText EDPasswprd;
    private Spinner spinner;
    private Spinner spinnerSucursal;
    private Spinner spinnerTvFuncionalidad;
    private AlertDialog ad;
    private ProgressDialog progressBar;
    String android_id = "";
    private SpinerAdapterDeviceType Adapter;
    public static List<DeviceType> DeviceTypeList;
    private AlertDialog alertDialog;
    public static ReturnInfo ObjReturn;
    private TextView txtLabelFuncionalidad;
    private Button btnConf;
    private Button btnBuscar;
    private Button btnModificar;
    private Context con;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_way_viewer_config);
        android_id = Secure.getString(getContentResolver(),
                Secure.ANDROID_ID);

        try {
            con =  createPackageContext(getString(R.string.pakagePreference), 0);//first app package name is "com.sharedpref1"
        }
        catch (PackageManager.NameNotFoundException e) {
            Log.e("Not data shared", e.toString());
        }

        String serialnum = null;
        WifiManager wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo();
        serialnum = info.getMacAddress();

        if (serialnum != null) {
            android_id += serialnum;
        }

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);


        //combo de tipo de dispositivo
        GetDeviceType();
        Adapter =
                new SpinerAdapterDeviceType(
                        WayViewerConfig.this,
                        android.R.layout.simple_spinner_item,
                        DeviceTypeList);
        spinner =
                (Spinner) findViewById(R.id.SpnTipoDispositivo);
        Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(Adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                if(((DeviceType) spinner.getSelectedItem()).Id() == 2){ //tv seleccionado
                    spinnerTvFuncionalidad.setVisibility(View.VISIBLE);
                    txtLabelFuncionalidad.setVisibility(View.VISIBLE);
                }else{
                    spinnerTvFuncionalidad.setVisibility(View.GONE);
                    txtLabelFuncionalidad.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        //-------------------------------------------------------------

        //---------------------------------------------
        //sucursales
        spinnerSucursal = (Spinner) findViewById(R.id.SpnSucursal);

        //------------------------------------------------

        //---------------------------------------------
        //Funcionalidad del tv
        spinnerTvFuncionalidad = (Spinner) findViewById(R.id.SpnTvFuncionalidad);
        txtLabelFuncionalidad = (TextView) findViewById(R.id.txtLabelFuncionalidad);
        Adapter =
                new SpinerAdapterDeviceType(
                        WayViewerConfig.this,
                        android.R.layout.simple_spinner_item,
                       GetUtilityTv());
        Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTvFuncionalidad.setAdapter(Adapter);
        //-------------------------------------------------

        alertDialogBuilder.setTitle("Your Title");

        // set dialog message
        alertDialogBuilder
                .setTitle("Mensaje")
                .setCancelable(false)
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // if this button is clicked, close
                        // current activity
                        dialog.cancel();
                    }
                });
                /*.setNegativeButton("No",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // if this button is clicked, just close
                        // the dialog box and do nothing
                        dialog.cancel();
                    }
                });*/

        // create alert dialog
        ad = alertDialogBuilder.create();

        btnConf =
                (Button) findViewById(R.id.BtnRegDis);

        EDKey =
                (EditText) findViewById(R.id.TxtLlave);
        EDdescript =
                (EditText) findViewById(R.id.TxtDescript);


        EDuser =
                (EditText) findViewById(R.id.TxtUsuario);


        EDPasswprd =
                (EditText) findViewById(R.id.TxtPassword);



        btnModificar = (Button) findViewById(R.id.BtnLimpiar);

        btnModificar.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        LimpiaDatos(false);
                        EDKey.setText("");
                    }
                });


        btnConf.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        if (EDKey.getText().toString().trim().equals("")) {
                            EDKey.setError("La llave es requerida");
                            return;
                        }

                        if (EDdescript.getText().toString().trim().equals("")) {
                            EDdescript.setError("La Descripción es requerida");
                            return;
                        }

                        if (EDuser.getText().toString().trim().equals("")) {
                            EDuser.setError("El usuario es requerido");
                            return;
                        }

                        if (EDPasswprd.getText().toString().trim().equals("")) {
                            EDPasswprd.setError("El password es requerido");
                            return;
                        }
                        String[] params = new String[6];
                        params[0] = String.valueOf(((DeviceType) spinnerSucursal.getSelectedItem()).Id());
                        params[1] = String.valueOf(((DeviceType) spinner.getSelectedItem()).Id());
                        if(((DeviceType) spinner.getSelectedItem()).Id() ==2)
                            params[2] = String.valueOf(((DeviceType) spinnerTvFuncionalidad.getSelectedItem()).Id());
                        else
                            params[2] ="0";

                        params[3] = EDdescript.getText().toString().trim();
                        params[4] = EDuser.getText().toString().trim();
                        params[5] = Base64.encodeToString(EDPasswprd.getText().toString().trim().getBytes(), Base64.DEFAULT);

                        AsyncRegistrerWSCall objWS = new AsyncRegistrerWSCall();
                        objWS.execute(params);
                    }
                }
        );


        btnBuscar = (Button) findViewById(R.id.BtnBuscaCliente);
        btnBuscar.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(EDKey.getText().toString().trim().equals("")){
                            EDKey.setError("La llave es requerida");
                            return;
                        }
                        String[] params = new String[1];
                        params[0] = EDKey.getText().toString();
                        AsyncGetClientKeySearch ws = new AsyncGetClientKeySearch();
                        ws.execute(params);
                    }
                });

        LimpiaDatos(false);
        EDKey.setText("");

    }

    private void LimpiaDatos(boolean blnAct) {
        EDKey.setEnabled(!blnAct);
        EDdescript.setEnabled(blnAct);
        EDdescript.setText("");
        EDuser.setEnabled(blnAct);
        EDuser.setText("");
        EDPasswprd.setEnabled(blnAct);
        EDPasswprd.setText("");
        btnConf.setEnabled(blnAct);
        spinner.setEnabled(blnAct);
        spinnerSucursal.setEnabled(blnAct);
       /* spinnerTvFuncionalidad.setVisibility(View.GONE);
        txtLabelFuncionalidad.setVisibility(View.GONE);*/
        btnModificar.setVisibility(View.GONE);
    }

    private class AsyncRegistrerWSCall extends AsyncTask<String, Void, MensajeSalida> {
        private String TvFunctionality = "";
        private String StrSucursal = "";
        @Override
        protected MensajeSalida doInBackground(String... params) {
            TvFunctionality = params[2];
            StrSucursal = params[0];
            //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name),Context.MODE_PRIVATE);
            SharedPreferences sharedPref = null;
            if(con != null) {
                sharedPref = con.getSharedPreferences(
                        getString(R.string.app_name), Context.MODE_PRIVATE);
            }else{
                sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
            }
            return Services.DeviceRegister(WayViewerConfig.this,
                    sharedPref.getString("RegisterID","0"),
                    android_id,
                    params[3],
                    StrSucursal,
                    params[1],
                    TvFunctionality,
                    params[4],
                    params[5]);

        }
        @Override
        protected void onPostExecute(MensajeSalida result) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                    WayViewerConfig.this);
            boolean ShowerrorMsg = false;
            if(result.IntError == 1) {
                String[] spli=result.Mensaje.split("\\|");

                if(spli.length>1) {
                    //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);

                    SharedPreferences sharedPref = null;
                    if(con != null) {
                        sharedPref = con.getSharedPreferences(
                                getString(R.string.app_name), Context.MODE_PRIVATE);
                    }else{
                        sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                    }

                    SharedPreferences.Editor editor = sharedPref.edit();

                    editor.putString("RegisterID", spli[1]);
                    editor.putString("TvFunctionality", TvFunctionality);
                    editor.putString("Sucursal", StrSucursal);
                    editor.commit();

                    alertDialogBuilder
                            .setTitle("Mensaje")
                            .setMessage("Se ha realizado el registro corrrectamente y sera redireccionado a la aplicación")
                            .setCancelable(false)
                            .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // if this button is clicked, close
                                    // current activity
                                    AsyncGetINWSCall objWS = new AsyncGetINWSCall();
                                    objWS.execute();
                                }
                            });

                    // create alert dialog
                    ad = alertDialogBuilder.create();
                    ad.show();
                }else{
                    ShowerrorMsg = true;
                    Log.e("ErrorRegister",result.Mensaje);
                    result.Mensaje = "Se ha presentado un error y su solicitud no puede ser atendida";
                }

            }else{
                ShowerrorMsg = true;
            }

            if(ShowerrorMsg){
                if(result.Mensaje.equals("")) result.Mensaje ="Se ha presentado un error y la solicitud no puede ser atendida";
                alertDialogBuilder
                        .setTitle("Mensaje")
                        .setMessage(result.Mensaje)
                        .setCancelable(false)
                        .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                ad.dismiss();
                            }
                        });

                // create alert dialog
                ad = alertDialogBuilder.create();
                ad.show();
            }

            progressBar.dismiss();
        }
        @Override
        protected void onPreExecute() {
            progressBar = ProgressDialog.show(WayViewerConfig.this, "", "Procesando...");
        }
    }

    private void GetDeviceType(){
        WayViewerConfig.DeviceTypeList = new ArrayList<DeviceType>();

       /* DeviceType objDevice = new DeviceType(1,"LapinSurvey");
        WayViewerConfig.DeviceTypeList.add(objDevice);*/

        DeviceType objDevice = new DeviceType(2,"WayTV");
        WayViewerConfig.DeviceTypeList.add(objDevice);
    }

    private ArrayList<DeviceType> GetUtilityTv(){
        //1.publicidad fija
        //2.Solo Publicidad en parrilla
        //3.Experiencias y publicidad
        //4.Solo Experiencias en parrilla

        ArrayList<DeviceType> listP =  new ArrayList<DeviceType>();
        listP.add(new DeviceType(1,"Publicidad Fija"));
        listP.add(new DeviceType(2,"Solo Publicidad en parrilla"));
        listP.add(new DeviceType(3,"Solo Experiencias en parrilla"));
        listP.add(new DeviceType(4,"Experiencias y Publicidad"));
        return listP;
    }

    private ArrayList<DeviceType> GetDeviceTypeFromSucursal(ArrayList<SucursalLapinTv> objSucList){
        ArrayList<DeviceType> listP =  new ArrayList<DeviceType>();
        for(int i= 0;i<objSucList.size();i++){
            listP.add(new DeviceType(objSucList.get(i).IdSucursal,objSucList.get(i).NombreSucursal));
        }
        return listP;
    }

    /**
     * Llamado al webservice para obtener la información del dispositivo
     */
    private class AsyncGetINWSCall extends AsyncTask<String, Void, ReturnInfo> {
        @Override
        protected ReturnInfo doInBackground(String... params) {
            String android_id = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ANDROID_ID);

            String serialnum = null;
            WifiManager wifiManager = (WifiManager) WayViewerConfig.this.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wifiManager.getConnectionInfo();
            serialnum = info.getMacAddress();

            if (serialnum != null) {
                android_id += serialnum;
            }

            //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
            SharedPreferences sharedPref = null;
            if(con != null) {
                sharedPref = con.getSharedPreferences(
                        getString(R.string.app_name), Context.MODE_PRIVATE);
            }else{
                sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
            }

            return Services.IngresarLapinTv(WayViewerConfig.this,
                    sharedPref.getString("RegisterID", ""),
                    android_id
            );
        }

        @Override
        protected void onPostExecute(ReturnInfo result) {
            if (result != null) {
                if (result.IntCode() == 0 || result.IntError() != 0) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage(result.StrMenssage());
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                            return;
                        }
                    });
                    alertDialog.show();
                } else {
                    //agregar el waytoken en las preferencias
                    if(result.WayToken() != null){
                        if(result.WayToken() != "") {
                            //SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                            SharedPreferences sharedPref = null;
                            if(con != null) {
                                sharedPref = con.getSharedPreferences(
                                        getString(R.string.app_name), Context.MODE_PRIVATE);
                            }else{
                                sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
                            }
                            SharedPreferences.Editor editor = sharedPref.edit();
                            editor.putString("WayToken", result.WayToken());
                            Gson gson = new Gson();
                            editor.putString("objInfoConect", gson.toJson(result));
                            editor.commit();
                        }
                    }
                    //indica que es un tv y se debe iniciar la actividad de publicidad
                    if (result.IntCode() == 2) {
                        Intent myIntent = new Intent(WayViewerConfig.this, ActivityPublicity.class);
                        myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        WayViewerConfig.this.startActivity(myIntent);
                        finish(); // Call once you redirect to another activity
                    }else{
                        Intent myIntent = new Intent(WayViewerConfig.this, WayViewerSurvey.class);
                        myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        WayViewerConfig.this.startActivity(myIntent);
                        finish(); // Call once you redirect to another activity
                    }
                }
            } else {
                if (WayViewerConfig.rslt != "") {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage(WayViewerConfig.rslt);
                    alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                            return;
                        }
                    });
                    alertDialog.show();
                }
            }
            progressBar.dismiss();
        }

        @Override
        protected void onPreExecute() {
            progressBar = ProgressDialog.show(WayViewerConfig.this, "", "Procesando...");
        }
    }
    /********************************************************************************************/

    private class AsyncGetClientKeySearch extends AsyncTask<String, Void, ClienteLapinTv> {
        @Override
        protected ClienteLapinTv doInBackground(String... params) {
            return Services.ClientKeySearch(WayViewerConfig.this,params[0].toString());
        }

        @Override
        protected void onPostExecute(ClienteLapinTv result) {
            if(result.IntError ==1){
                LimpiaDatos(true);
                EDKey.setEnabled(false);
                btnModificar.setVisibility(View.VISIBLE);
                btnBuscar.setVisibility(View.GONE);

                Adapter =
                        new SpinerAdapterDeviceType(
                                WayViewerConfig.this,
                                android.R.layout.simple_spinner_item,
                                GetDeviceTypeFromSucursal(result.SucursalList));
                Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerSucursal.setAdapter(Adapter);
            }else{
                String StrMensaje = "El código de cliente digitado no es válido";
                if(result.IntError == 99) {
                    if(result.Mensaje.equals(""))
                        StrMensaje = "Se ha presentado un error y la solicitud no puede ser atendida";
                    else
                        StrMensaje = result.Mensaje;
                }
                ad.setTitle("Error");
                ad.setMessage(StrMensaje);
                ad.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        ad.dismiss();
                        return;
                    }
                });
                ad.show();
            }
            progressBar.dismiss();
        }

        @Override
        protected void onPreExecute() {
            progressBar = ProgressDialog.show(WayViewerConfig.this, "", "Consultando Cliente...");
        }
    }
}
