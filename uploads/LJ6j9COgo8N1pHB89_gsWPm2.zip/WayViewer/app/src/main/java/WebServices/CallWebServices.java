package WebServices;
import android.view.View;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import java.util.ArrayList;

import com.WayViewer.waysurveyviewer.app.ActivityPublicity;
import com.WayViewer.waysurveyviewer.app.BootConexWait;
import com.WayViewer.waysurveyviewer.app.BootReceiver;
import com.WayViewer.waysurveyviewer.app.BusinessObjects.ReturnInfo;
import com.WayViewer.waysurveyviewer.app.WaySurveyMain;
import com.WayViewer.waysurveyviewer.app.WayViewerConfig;
import com.WayViewer.waysurveyviewer.app.WayViewerSurvey;
import com.google.gson.Gson;
import java.util.List;
import com.google.gson.reflect.TypeToken;

/**
 * Created by Manuel on 11/07/2014.
 */
public class CallWebServices {
    public  final String WSDL_TARGET_NAMESPACE = "http://tempuri.org/";
    //public  final String SOAP_ADDRESS = "http://www.waysolutions.co:8086/WSApps.asmx";
    //public  final String SOAP_ADDRESS = "http://192.168.0.5:8090/WSApps.asmx";
    public  final String SOAP_ADDRESS = "http://www.waysolutions.co:8085/WSApps.asmx";
    public CallWebServices(){

    }
    public void ActivarLlave(
            String numeroActivacion,
            String llaveRegistro,
            String registroEquipo,
            String descripcionEQ,
            String User,
            String Password,
            String DeviceTypeID
    )
    {
        String SOAP_ACTION = "http://tempuri.org/ActivarLlave";
        String OPERATION_NAME = "ActivarLlave";
        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();
        pi.setName("usuarioApp");
        pi.setValue("RufoKorn");
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("passwordApp");
        pi.setValue("*3102yaWehT*");
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("numeroActivacion");
        pi.setValue((numeroActivacion==""?"0":numeroActivacion));
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("llaveRegistro");
        pi.setValue(llaveRegistro);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("registroEquipo");
        pi.setValue(registroEquipo);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("descripcionEQ");
        pi.setValue(descripcionEQ);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("User");
        pi.setValue(User);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("Password");
        pi.setValue(Password);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("idTipoDispositivo");
        pi.setValue(DeviceTypeID);
        pi.setType(String.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
                SoapEnvelope.VER11);
        envelope.dotNet = true;

        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS);
        Object response=null;

        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse();
            WayViewerConfig.rslt = response.toString();
        }
        catch (Exception exception)
        {
            WayViewerConfig.rslt="99;Se ha presentado un error " + exception.toString();
        }
    }

    public void IngresoAplicacion(
            String numeroActivacion,
            String registroEquipo,
            int SenderAct
    )
    {
        String SOAP_ACTION = "http://tempuri.org/IngresoAplicacion";
        String OPERATION_NAME = "IngresoAplicacion";
        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();
        pi.setName("usuario");
        pi.setValue("RufoKorn");
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("password");
        pi.setValue("*3102yaWehT*");
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("registroEquipo");
        pi.setValue(registroEquipo);
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("numeroActivacion");
        pi.setValue((numeroActivacion==""?"0":numeroActivacion));
        pi.setType(String.class);
        request.addProperty(pi);


        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
                SoapEnvelope.VER11);
        envelope.dotNet = true;

        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS);
        Object response=null;

        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse();
            Gson gson = new Gson();
            switch (SenderAct) {
                case 1:
                    WayViewerSurvey.rslt = "";
                    WayViewerSurvey.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
                case 2:
                    ActivityPublicity.rslt = "";
                    ActivityPublicity.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
                case 3:
                    WaySurveyMain.rslt = "";
                    WaySurveyMain.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
                case 4:
                    WayViewerConfig.rslt = "";
                    WayViewerConfig.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
            }
        }
        catch (Exception exception)
        {
            switch (SenderAct) {
                case 1:
                    WayViewerSurvey.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
                case 2:
                    ActivityPublicity.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
                case 3:
                    WaySurveyMain.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
                case 4:
                    WayViewerConfig.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
            }
        }
    }

    public void ObtenerIngresoID(
            String registroEquipo,
            int SenderAct
    )
    {
        String SOAP_ACTION = "http://tempuri.org/ObtenerIngresoID";
        String OPERATION_NAME = "ObtenerIngresoID";
        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();
        pi.setName("usuario");
        pi.setValue("RufoKorn");
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("password");
        pi.setValue("*3102yaWehT*");
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("registroEquipo");
        pi.setValue(registroEquipo);
        pi.setType(String.class);
        request.addProperty(pi);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
                SoapEnvelope.VER11);
        envelope.dotNet = true;

        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS);
        Object response=null;

        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse();
            Gson gson = new Gson();
            switch (SenderAct){
                case 1:
                    WaySurveyMain.rslt = "";
                    WaySurveyMain.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
                case 2:
                    BootReceiver.rslt = "";
                    BootReceiver.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
                case 3:
                    BootConexWait.rslt = "";
                    BootConexWait.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
            }


        }
        catch (Exception exception)
        {
            switch (SenderAct){
                case 1:
                    WaySurveyMain.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
                case 2:
                    BootReceiver.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
                case 3:
                    BootConexWait.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
            }
        }
    }

    public void ActualizarBorrado(
            String numeroActivacion,
            int SenderAct
    )
    {
        String SOAP_ACTION = "http://tempuri.org/ActualizarBorrado";
        String OPERATION_NAME = "ActualizarBorrado";
        SoapObject request = new SoapObject(WSDL_TARGET_NAMESPACE,OPERATION_NAME);

        PropertyInfo pi=new PropertyInfo();
        pi.setName("usuario");
        pi.setValue("RufoKorn");
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("password");
        pi.setValue("*3102yaWehT*");
        pi.setType(String.class);
        request.addProperty(pi);

        pi=new PropertyInfo();
        pi.setName("numeroActivacion");
        pi.setValue((numeroActivacion==""?"0":numeroActivacion));
        pi.setType(String.class);
        request.addProperty(pi);


        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
                SoapEnvelope.VER11);
        envelope.dotNet = true;

        envelope.setOutputSoapObject(request);

        HttpTransportSE httpTransport = new HttpTransportSE(SOAP_ADDRESS);
        Object response=null;

        try
        {
            httpTransport.call(SOAP_ACTION, envelope);
            response = envelope.getResponse();
            Gson gson = new Gson();
            switch (SenderAct) {
                case 1:
                    WayViewerSurvey.rslt = "";
                    WayViewerSurvey.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
                case 2:
                    ActivityPublicity.rslt = "";
                    ActivityPublicity.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
                case 3:
                    WaySurveyMain.rslt = "";
                    WaySurveyMain.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
                case 4:
                    WayViewerConfig.rslt = "";
                    WayViewerConfig.ObjReturn = gson.fromJson(response.toString(), ReturnInfo.class);
                    break;
            }
        }
        catch (Exception exception)
        {
            switch (SenderAct) {
                case 1:
                    WayViewerSurvey.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
                case 2:
                    ActivityPublicity.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
                case 3:
                    WaySurveyMain.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
                case 4:
                    WayViewerConfig.rslt = "99;Se ha presentado un error " + exception.toString();
                    break;
            }
        }
    }

}
